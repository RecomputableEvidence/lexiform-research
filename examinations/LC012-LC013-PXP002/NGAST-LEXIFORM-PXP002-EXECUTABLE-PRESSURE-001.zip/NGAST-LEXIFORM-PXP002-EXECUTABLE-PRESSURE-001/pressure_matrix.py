#!/usr/bin/env python3
"""New post-PXP-002 tests, imports frozen LC012/LC013 from a specified path.
No network, no subprocess in this file; stdlib-only. Positive control checks claimed
synthetic contract only, not independent policy validation or model learning.
"""
import argparse
import copy
import hashlib
import json
import pathlib
import sys
from collections import Counter

ap = argparse.ArgumentParser()
ap.add_argument('--implementation', choices=('LC012', 'LC013'), required=True)
ap.add_argument('--source-root', type=pathlib.Path, required=True)
ap.add_argument('--out', type=pathlib.Path, required=True)
args = ap.parse_args()
sys.path.insert(0, str(args.source_root / 'src'))
from fixtures import (blank, claim, condition, relation, reviewer, addclaim,
                      addcondition, addrelation, admit, ATOM)
from engine import agreement
from contract import sha


def build(extra_claims=(), rel=None, admission='PENDING', guard=None, ctx=None):
    L=blank(); L['reviewers'].append(reviewer())
    addclaim(L,claim('a','T'))
    for item in extra_claims: addclaim(L,item)
    if rel is not None:
        addrelation(L,rel,False)
        if admission == 'ADMITTED':L['admissions'].append(admit(rel['id'],rel['kind']))
        if admission == 'WITHHELD':L['admissions'].append(admit(rel['id'],rel['kind'],outcome='WITHHELD'))
    return L


def eval_case(L, expr=None, q=5, k=5, ctx='default'):
    return agreement(expr or ATOM,L,q,k,ctx)

# Each case has a stated expected value for LC013; LC012 is compared as a historical
# baseline and not scored against a retrospectively modified LC012 oracle.
cases={}
def add(name,ledger,expected_value='T',expected_pending=None,expect_invariant_to=None,
        forbidden_support=None, forbidden_qualifiers=None, expr=None, q=5,k=5,ctx='default'):
    cases[name] = dict(ledger=ledger,expected_value=expected_value,expected_pending=expected_pending,
       expect_invariant_to=expect_invariant_to,forbidden_support=forbidden_support or [],
       forbidden_qualifiers=forbidden_qualifiers or [],expr=expr,q=q,k=k,ctx=ctx)

# Only the phenomenon under test changes between baseline and each cell.
base=build(extra_claims=(claim('b','T'), claim('u','T',pred='other'),claim('v','T',pred='other'),
                               claim('context','T',kind='context',pred='note')))
add('C00_BASE',base)

def extend(ledger,link,approval='PENDING',guard_condition=None):
    L=copy.deepcopy(ledger)
    if guard_condition:addcondition(L,guard_condition)
    addrelation(L,link,False)
    if approval=='ADMITTED':L['admissions'].append(admit(link['id'],link['kind']))
    if approval=='WITHHELD':L['admissions'].append(admit(link['id'],link['kind'],outcome='WITHHELD'))
    return L

add('C01_UNRELATED_PENDING_CORRECTION',extend(base,relation('u-cor','CORRECTS','v','u')),
    expected_pending=[],expect_invariant_to='C00_BASE')
add('C02_TARGETED_PENDING_CORRECTION',extend(base,relation('t-cor','CORRECTS','b','a')),
    expected_value='U',expected_pending=['t-cor'])
add('C03_TARGETED_PENDING_DISPUTE',extend(base,relation('t-dis','DISPUTES','b','a')),
    expected_pending=['t-dis'])
add('C04_TARGETED_PENDING_CONTEXT',extend(base,relation('t-ctx','ADDS_CONTEXT','context','a')),
    expected_pending=['t-ctx'])
add('C05_UNRELATED_PENDING_CONTEXT',extend(base,relation('u-ctx','ADDS_CONTEXT','context','u')),
    expected_pending=[],expect_invariant_to='C00_BASE')
add('C06_UNRELATED_ADMITTED_CONTEXT',extend(base,relation('u-ctx-admitted','ADDS_CONTEXT','context','u'),'ADMITTED'),
    expected_pending=[],expect_invariant_to='C00_BASE',forbidden_qualifiers=['context'])
add('C07_TARGETED_ADMITTED_CORRECTION',extend(base,relation('t-cor-adm','CORRECTS','b','a'),'ADMITTED'),
    expected_pending=[])
add('C08_TARGETED_WITHHELD_CORRECTION',extend(base,relation('t-cor-withheld','CORRECTS','b','a'),'WITHHELD'),
    expected_pending=[])
add('C09_UNRELATED_ADMITTED_CORRECTION',extend(base,relation('u-cor-adm','CORRECTS','v','u'),'ADMITTED'),
    expected_pending=[],expect_invariant_to='C00_BASE')
add('C10_TARGETED_PENDING_SUPERSEDES',build(extra_claims=(claim('b','F',kind='policy',pred='enabled'),
    claim('a-policy','T',kind='policy',pred='enabled')),
    rel=relation('t-sup','SUPERSEDES','b','a-policy')),expected_value='U',
    expected_pending=['t-sup'],expr=dict(ATOM,kind='policy',predicate='enabled'))
add('C11_UNRELATED_PENDING_GUARD',extend(base,
    relation('u-guard','CORRECTS','v','u',guard=['FACT','gate']),
    guard_condition=condition('flag','gate','T')),expected_pending=[],
    expect_invariant_to='C00_BASE',forbidden_support=['e-flag'])
add('C12_TARGETED_FUTURE_REVIEW',extend(base,
    relation('future','CORRECTS','b','a'),approval='PENDING'),expected_value='U',
    expected_pending=['future'],k=2)
future=extend(base,relation('future','CORRECTS','b','a'),approval='PENDING')
future['admissions'].append(admit('future','CORRECTS',when=3))
add('C13_TARGETED_REVIEW_PAST_CUTOFF',future,expected_pending=[],k=3)
add('C14_TARGETED_PENDING_LAB_ONLY_DEFAULT',extend(base,
    relation('lab','CORRECTS','b','a',contexts=['lab'])),
    expected_pending=[],expect_invariant_to='C00_BASE',ctx='default')
add('C15_TARGETED_PENDING_LAB_ONLY_LAB',extend(base,
    relation('lab','CORRECTS','b','a',contexts=['lab'])),
    expected_value='U',expected_pending=['lab'],ctx='lab')
add('C16_UNRELATED_RESOLVED_FALSE',extend(base,
    relation('u-withheld','CORRECTS','v','u'),'WITHHELD'),
    expected_pending=[],expect_invariant_to='C00_BASE')
add('C17_TARGETED_ADMITTED_DISPUTE',extend(base,
    relation('t-dis-adm','DISPUTES','b','a'),'ADMITTED'),
    expected_pending=[])
add('C18_TARGETED_ADMITTED_CONTEXT',extend(base,
    relation('t-ctx-adm','ADDS_CONTEXT','context','a'),'ADMITTED'),
    expected_pending=[])

rows=[]
for name, c in cases.items():
    r=dict(case=name,source_ledger_sha256=sha(c['ledger']),status='RUN')
    try:
        got=eval_case(c['ledger'],c['expr'],c['q'],c['k'],c['ctx'])
        r['projection']=got
        if args.implementation=='LC013':
            mismatches=[]
            if got['value']!=c['expected_value']: mismatches.append('wrong_scalar')
            if c['expected_pending'] is not None and got['pending']!=c['expected_pending']:
                mismatches.append('wrong_pending')
            if any(t in got['support'] for t in c['forbidden_support']):mismatches.append('unrelated_support_leak')
            if any(t in got['qualifiers'] for t in c['forbidden_qualifiers']):mismatches.append('unrelated_qualifier_leak')
            prev=c['expect_invariant_to']
            if prev and got!=next(q['projection'] for q in rows if q['case']==prev):
                mismatches.append('unrelated_link_alters_projection')
            r['outcome']='PASS' if not mismatches else 'FAIL'
            r['mismatches']=mismatches
        else:r['outcome']='BASELINE_OBSERVED_NO_RETROACTIVE_RESCORING'
    except Exception as e:
        r['status']='ERROR';r['outcome']='ERROR';r['exception']=repr(e)
    rows.append(r)

report=dict(run_id='PXP-002-LEXIFORM-PRESSURE-001',version=args.implementation,
  source_root=args.source_root.name,scope='SYNTHETIC_SPEC_CONFORMANCE_ONLY',
  cases=len(rows),counts=dict(Counter(x['outcome'] for x in rows)),results=rows)
args.out.parent.mkdir(parents=True,exist_ok=True)
args.out.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n',encoding='utf-8')
print(json.dumps({'implementation':args.implementation,'cases':len(rows),'outcomes':report['counts'],
                  'output':str(args.out)},sort_keys=True))
sys.exit(1 if 'ERROR' in report['counts'] or 'FAIL' in report['counts'] else 0)

# PXP-002 → executable LexiFORM follow-through

The [examination](EXAMINATION.md) reports a locally preregistered 19-fixture synthetic semantic-pressure test against exact preserved LC012 and LC013 archives. **LC013 19/19 PASS, historical LC012 behavior retained, five case-level differences observed**, with original test suites and fresh second extraction also passing.

For fully offline reproduction, run `py -3 .\reproduce_offline.py` inside this folder after checking the source. No API key or cloud access required. The complete original archives, frozen protocol, observed projections and reproduction receipt are included.

#!/usr/bin/env python3
"""Post-run deterministic reproduction; offline and standard-library only.
Unpacks hash-identified originals in a fresh temp dir and reruns frozen case matrix.
This script postdates preregistration and therefore does not form part of it.
"""
import argparse,hashlib,json,pathlib,subprocess,sys,tempfile,zipfile
p=argparse.ArgumentParser()
p.add_argument('--root',type=pathlib.Path,default=pathlib.Path(__file__).resolve().parent)
p.add_argument('--output',type=pathlib.Path,default=None)
a=p.parse_args();root=a.root.resolve()
freeze=json.loads((root/'PREREGISTRATION.json').read_text())
if hashlib.sha256((root/'pressure_matrix.py').read_bytes()).hexdigest()!=freeze['test_script_sha256']:
    raise SystemExit('FROZEN SCRIPT HASH MISMATCH')
records={}
with tempfile.TemporaryDirectory(prefix='lexiform-pressure-') as tmp:
 temp=pathlib.Path(tmp)
 for label,info in freeze['source_objects'].items():
    src=root/(label+'.zip')
    if hashlib.sha256(src.read_bytes()).hexdigest()!=info['sha256']:raise SystemExit(f'{label} ARCHIVE HASH MISMATCH')
    with zipfile.ZipFile(src) as zipf:
        if zipf.testzip() is not None:raise SystemExit('ZIP CRC FAILURE '+label)
        for entry in zipf.infolist():
            if entry.is_dir():continue
            pp=pathlib.PurePosixPath(entry.filename)
            if pp.is_absolute() or '..' in pp.parts or '\\' in entry.filename:raise SystemExit('PATH UNSAFE')
            destination=temp.joinpath(*pp.parts);destination.parent.mkdir(parents=True,exist_ok=True)
            destination.write_bytes(zipf.read(entry))
    impl=temp/label
    manifest=[]
    for row in (impl/'MANIFEST.sha256').read_text().splitlines():
        digest,sep,rel=row.partition('  ')
        if sep!='  ' or hashlib.sha256((impl/rel).read_bytes()).hexdigest()!=digest:
            raise SystemExit(f'{label} MANIFEST MISMATCH: {rel}')
        manifest.append(rel)
    v='LC012' if label.startswith('LC-EXP-012') else 'LC013'
    # Execute trusted, inspected scripts against only local synthetic inputs.
    completed=subprocess.run([sys.executable,'-B',str(impl/'run_all.py')],cwd=impl,
                             capture_output=True,text=True,timeout=90,check=False)
    if completed.returncode!=0:raise SystemExit('BASELINE SUITE FAILED '+label+' '+completed.stderr[-800:])
    outfile=temp/(v+'_reproduced.json')
    press=subprocess.run([sys.executable,'-B',str(root/'pressure_matrix.py'),'--implementation',v,
                          '--source-root',str(impl),'--out',str(outfile)],capture_output=True,
                         text=True,timeout=90,check=False)
    if press.returncode!=0:raise SystemExit('PRESSURE SUITE FAILED '+v+' '+press.stdout+' '+press.stderr[-800:])
    result=json.loads(outfile.read_text())
    original=json.loads((root/(v+'_pressure_results.json')).read_text())
    if result!=original:raise SystemExit('SOURCE-SPECIFIED PROJECTION MISMATCH '+v)
    r=json.loads((impl/'results'/'test_results_latest.json').read_text())
    records[v]={'archive_sha256':info['sha256'],'manifest_entries':len(manifest),'baseline_tests':r['tests_run'],
                'baseline_pass':r['passed'],'pressure_cases':result['cases'],'outcomes':result['counts'],
                'recomputed_projections_identical':True}
print(json.dumps({'result':'FRESH_EXTRACTION_SAME_IMPLEMENTATION_RECOMPUTATION_PASS',
                  'source_prereg_sha256':hashlib.sha256((root/'PREREGISTRATION.json').read_bytes()).hexdigest(),
                  'records':records},sort_keys=True))
if a.output:
 a.output.write_text(json.dumps({'status':'PASS','prereg_sha256':hashlib.sha256((root/'PREREGISTRATION.json').read_bytes()).hexdigest(),
                                    'versions':records},indent=2,sort_keys=True)+'\n')

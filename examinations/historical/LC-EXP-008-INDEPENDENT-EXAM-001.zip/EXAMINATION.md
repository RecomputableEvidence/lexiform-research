# LC-EXP-008 — Independent cross-account artifact examination

**Disposition:** OBSERVED, bounded. Not a successor and no changes to the submitted archives.

## Sources and identity

- `LexiFORM.zip` raw SHA-256: `1e8a89ce567bbc0a436739389be6c2bb2c5721d1040264ea0055ee1b51ae09e5`.
- `lens_methods.zip` raw SHA-256: `b03c76a11e782af6ef136754e822ce96bea0ba5635ec7da76e0a03e9af74d4db`.
- `LC-EXP-008-PORTABLE-AUDIT-001.zip` raw SHA-256: `7af3bd382abf3289d4282a9be3d36dd10092ad9bbe0e19b5b7d15b68a85c1ddd`.
- Both provided Lens method documents match the copies embedded in LC-008 exactly.
- All seven source ZIP hashes in `SOURCE_INVENTORY.json` match the seven contained in `LexiFORM.zip`.
- Embedded LC-007 SHA-256 matches the declared `b47645864323e90e95ce0408d1602cc36ef801dcbc78c244bfdf0d5954d4ac00`.

## Independent execution

- LC-008 `verify_manifest.py`: 21/21 supplied files matched, excluding the manifest itself.
- `run_all.py`: 15/15 LC-008 tests passed. Its runner executed LC-007 and reported 10/10 plus 25 inherited groups.
- Standalone `verify_packet.py`: original historical T example accepted as `UNANCHORED` with no external tip. Later U packet rejected with the original T packet's ledger tip (`external ledger tip mismatch`).
- Re-running `run_benchmark.py` in a copy yielded replay median 4.316, 16.3226 and 35.5267 ms (8, 32 and 64 segments respectively), on the local runtime. Do not compare these measurements as a matched LLM or independent semantic advantage.

## New discriminating pressure finding: anchor scope

A separately constructed T packet for `R(A,B)` and a U packet for `R(B,A)` use an identical single-entry ledger and identical trusted ledger tip. Both replay correctly and report `EXTERNALLY_ANCHORED` when **only that same trusted ledger tip** is supplied. They have different packet hashes. Supplying the first packet's trusted packet hash against the second correctly produces `external packet hash mismatch`.

This is **not** a forged-expression acceptance bug under a complete independently committed packet: the existing `trusted_packet_hash` control is effective in this probe. The narrower observation is that `EXTERNALLY_ANCHORED` does not state *what* is anchored. A ledger tip can externally bind evidence history without externally binding a query, its definitions, or its historical issuance. An operator could mistake a ledger-anchored replay-consistent interpretation for an independently anchored interpretation event. A future revision should use two separately named anchor statuses and require explicit external context/packet commitment before asserting historical query/interpretation authenticity.

Reproduction: `python probe_anchor_scope.py /path/to/extracted/LC-EXP-008-PORTABLE-AUDIT-001`.

## Other evidence limitations

- The READMEs and EXAMINATION.md quote replay figures **4.30 / 18.83 / 38.22 ms**, whereas the frozen `results/benchmark_008.json` says **4.4448 / 17.323 / 35.0167 ms**. This may reflect different benchmark runs, but there are no execution IDs linking the prose figures to the frozen receipt. Keep them separate as discrepant reported observations; do not silently reconcile.
- A separate account/incognito run reduces dependence on originating account conversation history, but does not establish a formally blinded examination. The reviewer received all prior research archives, the two method specifications and a successor-optional objective. Raw prompt/response and comparator control traces were not furnished in these packages. Method effectiveness and model-independent semantic interpretation remain unproven.
- The verifier uses a distinct typed evaluator but inherits the formal grammar, declared evidence semantics, and frozen code lineage. It demonstrates independent process replay within a shared interpretive contract, not independently discovered meaning.
- The report explicitly identifies LC-008 as `CANDIDATE_EXECUTED`, `NOT_FROZEN`; naming the ZIP digest here identifies the byte snapshot examined, without retroactively changing its stated release disposition.

**Standing:** Portable full-history verification is reproduced under stated syntactic and evidence rules. Independent source authentication, historical query issuance, lossless compressed restart, lexicon-specific computational superiority, and semantic grounding remain open.

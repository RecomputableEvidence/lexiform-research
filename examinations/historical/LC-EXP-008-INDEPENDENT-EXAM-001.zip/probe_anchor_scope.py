"""Independent LC008 trust-scope probe. Usage: python probe_anchor_scope.py /path/to/extracted/LC-EXP-008-PORTABLE-AUDIT-001"""
import json,sys,tempfile
from pathlib import Path

root = Path(sys.argv[1]).resolve()
sys.path.insert(0,str(root/'src'))
from dependencies import load_dependency_paths

def row(i,atom,value):
    return {'id':i,'atom':atom,'value':value,'observed_stage':0,'valid_from':0,
            'valid_until':10,'source':'declared','persistence_policy':'bounded'}

with tempfile.TemporaryDirectory(prefix='lc008-independent-probe-') as temporary:
    verified = load_dependency_paths(temporary)
    from registry import FrozenDefinitions
    from persistent_ledger import AppendLedger
    from selective_audit import SelectiveAudit
    from portable_audit import export_packet,verify_packet
    definitions=FrozenDefinitions({
        'H1':{'version':1,'parameters':['a','b','c'],
              'expression':'C(R({a},{b}),R({b},{c}))'},
        'H2':{'version':2,'parameters':['a','b','c'],
              'expression':'J(P({b}),C(R({a},{b}),R({b},{c})))'}
    })
    snapshot=AppendLedger([row('e0','R(A,B)','T')]).snapshot()
    packets=[]
    for expression in ('R(A,B)','R(B,A)'):
        engine=SelectiveAudit(definitions)
        handle=engine.evaluate(expression,snapshot,0,0)['audit_handle']
        packet=export_packet(engine,handle,snapshot,definitions,[0])
        verification=verify_packet(packet,trusted_ledger_tip=snapshot.digest)
        assert verification['verified'] and verification['anchor_status']=='EXTERNALLY_ANCHORED'
        packets.append((expression,packet,verification))
    assert packets[0][1]['expected']['value']=='T'
    assert packets[1][1]['expected']['value']=='U'
    assert packets[0][1]['ledger']['tip']==packets[1][1]['ledger']['tip']
    assert packets[0][1]['packet_sha256']!=packets[1][1]['packet_sha256']
    packet_anchor_rejected_alternative=False
    try:
        verify_packet(packets[1][1], trusted_packet_hash=packets[0][1]['packet_sha256'])
    except ValueError as e:
        packet_anchor_rejected_alternative=('external packet hash mismatch' in str(e))
    assert packet_anchor_rejected_alternative
    output={
        'experiment':'LC-EXP-008-INDEPENDENT-EXAM-001',
        'result':'PASS — establishes anchor-scope distinction; not a bypass of independently committed packet hashes',
        'predecessor_manifests':verified,
        'common_ledger_tip':snapshot.digest,
        'results':[{'expression':expr,'conclusion':pkt['expected']['value'],
                    'packet_hash':pkt['packet_sha256'],
                    'reported_anchor_status':ver['anchor_status']} for expr,pkt,ver in packets],
        'independently_committed_packet_hash_blocks_alternative':packet_anchor_rejected_alternative,
    }
    print(json.dumps(output,indent=2,sort_keys=True))

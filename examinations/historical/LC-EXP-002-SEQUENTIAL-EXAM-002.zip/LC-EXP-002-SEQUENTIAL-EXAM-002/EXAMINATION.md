# LC-EXP-002 — Sequential Subject Examination 002

**Date:** 2026-10-17  
**Sequence requested:** Lens Removal, then Lens Shift v0.1.4  
**Subject:** submitted `LC-EXP-002-EXECUTED-SUCCESSOR(1).zip`  
**Subject archive SHA-256:** `309a07507490ef00a9e56e329a11ce8743b866daa486f544a3c2ecebe5cb6f20`  
**Lens Removal SHA-256:** `f9a6c997a30148a9f84998c2817b2efca21e16445dc2db4b2dbd261d9499f184`  
**Lens Shift v0.1.4 candidate SHA-256:** `841a12c1351df15cbabe794bf96577fe52ceab726903cee0f4e6a32bc1898e45`  
**Execution boundary:** read-only exploration and probes; no successor repair, no neural-model training, and no assertion of empirical method qualification.

## 1 — Lens Removal: examination without privileging the original efficiency or novelty thesis

What the artifact implements is a **bounded evidence-conditioned path calculus**. Its operative language has directed `R` links, `C` path composition, `J` observed-guard conjunction, `AT` query-stage selection and named `H1/H2` expansions. REL-A and REL-B execute the same written semantics with different algorithms. Their agreement demonstrates bounded interoperability, not independently discovered reference or a self-decoding lexicon.

Three distinct goals have sometimes appeared adjacent and should be kept independent:

1. **Expressive abbreviations:** shorter terms that expand to canonical structures. *Implemented in a narrow way* by `H1/H2`.
2. **Reusable computation:** resolved definitions, evidence lookups and validated intermediate results reused without repeating work. *Not implemented as shared persistent relational execution*; macros expand into freshly evaluated structure on each call.
3. **Semantic continuity:** a reasoned claim retains its typed meaning, scope and provenance across re-expression and changed knowledge. *Partially implemented* for a declared path calculus; temporal source-stage and macro invocation/version are not part of the returned audit projection.

The technical opportunity is therefore not established compression. It is **avoiding duplicated interpretation and computation while retaining the validity conditions of those results**. That requires a matched baseline and a temporal/evidentiary contract before an efficiency claim.

## 2 — Lens Shift: targeted discriminating probes against the artifact

The following are **subject-level observations**, not Lens Shift utility or superiority claims. `subject_probes.py` is the executable evidence; `subject_probes.json` is its recorded output. Each observation was reproduced with REL-A and REL-B from a freshly extracted source ZIP.

### F1 — Query-stage equality does not establish common observation time — HIGH

Input: `R(A,B)` observed `T` at stage 0 and `R(B,C)` observed `T` at stage 2. Query `C(R(A,B),R(B,C))` at stage 2.

**Observed:** both evaluators return `T`, report common `stage:2` and preserve evidence IDs `OBS-L0`, `OBS-L2`. They reject explicit `C(AT(0,R(A,B)),AT(2,R(B,C)))` as mixed query stages.

**Interpretation:** not a contradiction of the published REL-1.0.0 rule: it explicitly uses latest-eligible-stage observation as a simplifying convention. But *as-of query stage*, *actual observation stage*, and *evidence validity interval* are distinct. The current reconstruction may suggest contemporaneous standing not established by the records. Volatile physical states need declared persistence or expiry policy. The claim ceiling is **last-known-evidence witness under configured carry-forward**, not **verified contemporaneous physical path**.

**Next discriminating test:** repeat the path with an expiring volatile link, a durable link, and evidence with explicitly bounded validity. A query after expiry must return `U` or a separately marked non-current value without erasing the former result.

### F2 — Version metadata is not enforced as a semantic contract — HIGH/MEDIUM

Constructors accepted a registry with `H1.version=999`, `H2.version=-5` and evaluated `H1(A,B,C)` normally. A correct constructor-level copy and mutation seal exists, but it does not validate *initial version semantics*.

**Observed:** `H1(A,B,C)` and `C(R(A,B),R(B,C))` return exactly equal structured projections. No macro invocation ID, version or registry hash appears in those projections.

**Interpretation:** equivalence of their *declared relational meaning* is legitimate; their *historical invocation and registry binding* are not represented. That is a traceability limitation, not proof of a wrong truth result.

**Next test:** require registry schema validation and return immutable execution references (input term hash, macro name/version, registry hash, expansion lineage). Preserve semantic-equivalence checks independently of identical audit identities.

### F3 — Genuine equivalence cases reproduce — POSITIVE

Both evaluators returned identical projections for:

- `J(P(B),C(R(A,B),R(B,C)))` versus `C(J(P(B),R(A,B)),R(B,C))` (guard is bound to `B`); value `F` under the supplied evidence.
- `C(C(R(A,B),R(B,C)),R(C,D))` versus `C(R(A,B),C(R(B,C),R(C,D)))`; value `T`.

These cases expose a useful opportunity for provable `REWRITE` rules within the typed calculus. They do **not** demonstrate every rearrangement is safe or that the language has fully dynamic, context-sensitive descriptor semantics. An explicit equivalence proof should be recorded separately from evidence-driven `REASSESS` events.

### F4 — Reusable abbreviation currently avoids no link lookups — MEDIUM

With three evidence rows, both `H1(A,B,C)` and its explicit expansion inspected six evidence rows per evaluation in both engines. The macro changes source expression, not the amount of evidence scanning or the number of composed link operations.

**Next test:** pre-resolve a typed immutable graph with context- and evidence-bound memoization, compare against equivalent optimized typed-DAG baselines, and invalidate cached results on input, evidence, definition or validity changes. Warm results must be judged at equal correctness and under measured lookup and memory costs.

### F5 — Evidence scans are quadratic in the tested construction — HIGH for efficiency

Measured actual row visits (not inferred from wall-clock noise):

| Path edges / evidence rows | REL-A scanned rows | REL-B scanned rows |
|---:|---:|---:|
| 8 | 64 | 64 |
| 16 | 256 | 256 |
| 32 | 1,024 | 1,024 |
| 64 | 4,096 | 4,096 |

Under this construction, every link lookup walks the full evidence list: `n` lookups × `n` rows. This independently explains a key source of the observed poor scaling. Pre-indexing and persistent typed structure should be added to **both** lexiconic and ordinary typed baseline arms before attributing any improvement to one representation.

### F6 — Input integrity gaps from the earlier examination reproduce — HIGH

- Duplicate evidence identifiers with contradictory values produced `U`/`conflict` while returning duplicate `['DUP','DUP']`, so IDs cannot disambiguate the records.
- Negative-stage evidence at stage `-1` was eligible for a stage-0 query even though the published grammar describes non-negative stages.

**Next test:** validate evidence records and stage types at the ingress boundary, including uniqueness or immutable digest identities, nonnegative integral stages excluding Booleans, allowed atom forms, and explicit conflicts. Invalid records must not silently become valid observations or be confused with genuinely absent data.

### F7 — Previously observed coverage limitation remains relevant — MEDIUM

The 9,720 comparisons in the submitted generated suite arise from six distinct expression strings under 81 truth assignments repeated across selected instances. This supports truth-table agreement under controlled shapes, not broad structural diversity. Introduce withheld trees, novel identifiers, reversed relations, guard scope variants, stage propagation, negative/null cases, and a separately authored oracle. No test-count inflation should be used as a surrogate for coverage.

## 3 — Reconstructed successor priorities

### Gate 1: Evidence-bound meaning before performance optimization

1. Separate `query_stage`, `observed_stage` and `validity_interval`/`persistence_policy` in typed records and semantic projection.
2. Validate evidence and registry at creation and operation boundaries. Make conflicting/duplicate identities explicit.
3. Introduce two noninterchangeable recorded operations: `REWRITE` (equivalence-preserving under a named rule) and `REASSESS` (new conclusion licensed by new evidence, with predecessors retained).
4. Record macro definition identity and rule/evidence lineage in execution traces, even when equal semantic results have different computation histories.

### Gate 2: Discriminating cost and compositional evaluation

5. Develop held-out structurally novel positive, negative, and null compositions (separate generator and oracle).
6. Benchmark **equal-semantics** optimized typed-DAG, lexicon without reuse, lexicon with verified reuse, and an intermediate evidence-index-only ablation. Report cold and warm costs, cache hit rate, invalidation correctness, total allocations and memory.
7. Preserve cases where a conventional representation matches or exceeds the lexicon. This is a valid negative result, not a reason to redesign the comparator after observing its performance.

### Gate 3: Learning and unknown interpreter, separately

8. Only after bounded semantic contracts pass, add a learned ingress/egress participant on top of the same frozen grammar; keep oracle and representation failures separable from neural interpretation failures.
9. Treat unknown-interpreter decipherability and historical Codex provenance as a separate test with a different exposure contract. Neither is established by agreement between two known-specification interpreters.

## 4 — Standing and preservation

**Source archive:** preserved unchanged; archive and execution-method hashes listed above. A freshly extracted source ZIP passed `verify_manifest.py`: 28/28 matching files. It also passed the nine successor tests after manifest verification. The previously used extracted work tree separately had a modified results JSON and is not substituted for the frozen distribution.

**Claim ceiling:** independently reproduced source-level behavior, new bounded probes, and identified next test requirements; no claim of general semantic understanding, actual contemporaneous physical standing, compositional novelty beyond the specified grammar, computational superiority, causal efficacy of either analysis method, or validation of the missing 2025 Codex.

**Disposition:** retain LC-EXP-002 as a valid bounded predecessor. Develop LC-EXP-003 as a *new*, separately identified, evidence-bound successor; first prioritize evidence-time semantics and provenance validation, then computational reuse against a matched baseline.

## Reproduction

From this inspection folder:

```sh
python subject_probes.py /path/to/LC-EXP-002 /path/to/LC-EXP-002-EXECUTED-SUCCESSOR.zip
```

The script imports only the submitted relational engines, takes no network actions, makes no modifications to their code, and writes its own JSON result in this inspection folder.

"""Read-only LC-EXP-002 subject probes; does not alter submitted archive.

Usage: python subject_probes.py /path/to/LC-EXP-002
"""
import json, sys, hashlib, platform
from pathlib import Path
from copy import deepcopy

root = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parents[1] / 'LC-EXP-002'
sys.path.insert(0, str(root / 'src'))
from relational_a import RelationalA
from relational_b import RelationalB
macros = json.loads((root/'spec/relational_registry.json').read_text(encoding='utf-8'))['macros']
engines={'REL-A': RelationalA(macros),'REL-B': RelationalB(macros)}
E=[
    {'id':'OBS-L0','atom':'R(A,B)','stage':0,'value':'T'},
    {'id':'OBS-L2','atom':'R(B,C)','stage':2,'value':'T'},
    {'id':'OBS-P2','atom':'P(B)','stage':2,'value':'F'},
]
archive = Path(sys.argv[2]).resolve() if len(sys.argv)>2 else (root.parent/'LC-EXP-002-EXECUTED-SUCCESSOR(1).zip')
output={'python':platform.python_version(), 'submitted_archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest() if archive.is_file() else None,'probes':{}}

# Source-time vs query-time: a stage-0 link and a stage-2 link are treated as stage-2 path
for name,eng in engines.items():
    result=eng.evaluate('C(R(A,B),R(B,C))',E,2)
    output['probes'].setdefault('source_stage_vs_query_stage',{})[name]={
        'value':result['value'], 'reported_stage':result['stage'], 'support':result['support'], 'links':result['links']}
    try:
        eng.evaluate('C(AT(0,R(A,B)),AT(2,R(B,C)))',E,2)
        mixed='accepted'
    except ValueError:
        mixed='rejected'
    output['probes'].setdefault('explicit_mixed_query_stages',{})[name]=mixed

# Current version labels are not dynamically semantically checked; macro name controls expansion
relabel=deepcopy(macros)
relabel['H1']['version']=999
relabel['H2']['version']=-5
for name,constructor in [('REL-A',RelationalA),('REL-B',RelationalB)]:
    eng=constructor(relabel)
    result=eng.evaluate('H1(A,B,C)',E,2)
    output['probes'].setdefault('macro_version_metadata',{})[name]={
        'accepted_mislabeled_registry':True,'H1_version':relabel['H1']['version'],'value':result['value']}

# Macro invocation is elided from result; expansion and macro produce the same structured projection.
for name,eng in engines.items():
    m=eng.evaluate('H1(A,B,C)',E,2)
    expanded=eng.evaluate('C(R(A,B),R(B,C))',E,2)
    output['probes'].setdefault('macro_identity_projection',{})[name]={
        'macro_equals_expansion':m==expanded,
        'macro_name_in_result':('H1' in str(m)),
        'result_keys':sorted(m.keys())}

# Pure reformulation within the stipulated semantics: guard position, path grouping.
E4=[{'id':f'G{i}','atom':atom,'stage':2,'value':value} for i,(atom,value) in enumerate([
    ('R(A,B)','T'),('R(B,C)','T'),('R(C,D)','T'),('P(B)','F')])]
expressions={
    'outer_guard':'J(P(B),C(R(A,B),R(B,C)))',
    'inner_guard':'C(J(P(B),R(A,B)),R(B,C))',
    'left_assoc':'C(C(R(A,B),R(B,C)),R(C,D))',
    'right_assoc':'C(R(A,B),C(R(B,C),R(C,D)))',
}
for name,eng in engines.items():
    g1,g2=eng.evaluate(expressions['outer_guard'],E4,2),eng.evaluate(expressions['inner_guard'],E4,2)
    c1,c2=eng.evaluate(expressions['left_assoc'],E4,2),eng.evaluate(expressions['right_assoc'],E4,2)
    output['probes'].setdefault('equivalent_reformulations',{})[name]={
        'guard_placement_same_projection':g1==g2,'guard_value':g1['value'],
        'grouping_same_projection':c1==c2, 'grouping_value':c1['value']}

# Evidence identity collision same as earlier exam, captured as corroboration.
for name,eng in engines.items():
    collision=[{'id':'DUP','atom':'R(A,B)','stage':0,'value':'T'}, {'id':'DUP','atom':'R(A,B)','stage':0,'value':'F'}]
    result=eng.evaluate('R(A,B)',collision,0)
    output['probes'].setdefault('duplicate_evidence_id',{})[name]=result['support']['R(A,B)']
    negative=[{'id':'PRE','atom':'R(A,B)','stage':-1,'value':'T'}]
    result=eng.evaluate('R(A,B)',negative,0)
    output['probes'].setdefault('negative_stage',{})[name]=result['support']['R(A,B)']

# Count actual scanned input evidence rows; independent of timing noise.
class Tally(list):
    def __init__(self,*args):super().__init__(*args);self.scanned=0
    def __iter__(self):
        for x in super().__iter__():
            self.scanned += 1
            yield x

def chain(nodes):
    terms=[f'R({a},{b})' for a,b in zip(nodes,nodes[1:])]
    while len(terms)>1:
        nxt=[]
        for j in range(0,len(terms),2):
            nxt.append(f'C({terms[j]},{terms[j+1]})' if j+1<len(terms) else terms[j])
        terms=nxt
    return terms[0]

# Registered macros are syntactic substitutions; they do not cache evaluation.
for name,eng in engines.items():
    for expression,label in [('H1(A,B,C)','macro'),('C(R(A,B),R(B,C))','expanded')]:
        e=Tally(E)
        r=eng.evaluate(expression,e,2)
        output['probes'].setdefault('macro_vs_expanded_evidence_cost',{}).setdefault(name,{})[label]={
            'rows_scanned':e.scanned,'value':r['value'],'links':r['links']}

for name,eng in engines.items():
    for n in (8,16,32,64):
        nodes=[f'N{i}' for i in range(n+1)]
        records=Tally([{'id':f'I{i}','atom':f'R(N{i},N{i+1})','stage':0,'value':'T'} for i in range(n)])
        result=eng.evaluate(chain(nodes),records,0)
        output['probes'].setdefault('lookup_scanning',{}).setdefault(name,[]).append({
            'links':n,'evidence_rows':len(records),'rows_scanned':records.scanned,'verdict':result['value']})

report_path=Path(__file__).with_name('subject_probes.json')
report_path.write_text(json.dumps(output,indent=2,sort_keys=True)+'\n',encoding='utf-8')
print(json.dumps(output, indent=2, sort_keys=True))

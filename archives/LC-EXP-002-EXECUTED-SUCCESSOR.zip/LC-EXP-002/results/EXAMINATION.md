# LC-EXP-002 — Executed bounded examination

## Disposition

**Bounded semantic-composition behavior OBSERVED; broader lexiconic architecture and efficiency claims WITHHELD.**

- Predecessor root SHA-256 `1014aa4b0948ec04f0f859905a3af3dad35034368e5016300a7c29215079e9e8` remains independently identifiable and unchanged.
- Two independently implemented relational interpreters: recursive AST (REL-A), frame-stack/postfix VM (REL-B). Both follow a declared published grammar; they're not blind to its semantics, and the suite is not sequestered.
- Relation meaning is scope-sensitive and order-sensitive **within the declared grammar**: `C(R(A,B),R(B,C))` yields an A→C path witness when both edges are supported, whereas reversing the arguments is invalid (not silently interpreted as the same path). Adding a `J(P(B),...)` guard changes the truth of the witness when `P(B)` is false. `H1` and `H2` are explicitly distinct versioned definitions, not silent reinterpretation.
- Historical stages can be separately queried using `AT`; composing snapshots from different stages is rejected, not treated as continuity. Earlier evidence is queried rather than rewritten.
- Provenance and uncertainty are expressed as evidence IDs, observation stage, value `T/F/U`, and reason `observed/missing/conflict`. The reconstruction is a **bounded semantic support projection**, not exact recreation of the original natural-language input.

## Reparative findings from predecessor examination

- Repair R1: interpreter B deep-copies the constructor registry and rejects modifications of its live registry, so an external object mutation cannot silently change an expression.
- Repair R2: interpreter A caches a defensive copy of results and returns another copy on cache hits; callers cannot mutate the cached verdict or inject spurious referenced atoms through the returned object.

Both repairs were exercised with explicit hostile mutations, rather than inferred from code inspection alone.

## Runs and checks

- Original 7 tests rerun successfully on the successor copy; original source ZIP remains unchanged.
- New 9 tests passed, including 120 generated novel relational expressions over 81 three-valued assignments (9,720 oracle comparisons). Tests are deterministic, disclosed, non-sequestered, and do not prove broad language understanding.
- 17 named pressure probes reproduced expected behavior, including outside registry mutation, internal mutation detection, cached-result mutation, versioned macro contrast, historical replay, mixed-stage rejection, and reversed-chain rejection.
- A 32-link compositional path was parsed, evaluated, and reconstructed by both interpreters with matching semantic support outputs.

## Performance

`relational_scale.json` reports the two *unoptimized Python* engines on this machine. No optimized typed-DAG same-capability control was run, and no claim is made of superior latency, compression, or model inference efficiency. The versioned macro is a shorthand, but overall footprint must include the shared registry and interpreter costs.

## Retained limitations and risks

1. All semantics are designer-declared, not inductively learned or independently deciphered from an unknown key.
2. The grammar only expresses directed links, simple S/P guards, composition, macros and explicit stages. No open-domain meaning, nested natural-language modality, entity resolution, or general temporal authorization.
3. Endpoint typing rejects structurally invalid edges, but a valid path is **not** authority to perform any consequential action; the F/U statuses describe a chosen witness, not evidence of universal nonexistence.
4. Test evidence is artificial and unauthenticated; no independent source attestation, witness signature, or custody assurance.
5. Two engines share an authored specification and provided fixtures, and a shared evaluation platform; separate execution paths do not imply independent semantic correctness.
6. 32-link scaling is a small stress probe, not an asymptotic or production performance characterization; it does not show efficiency gains over a well-designed symbolic runtime.
7. Grammar v2 does not prove that relational placement dynamically changes individual descriptor definitions outside its formal operators. The composition is a constrained first step toward that question.
8. No relationship to the missing 2025 Codex is established other than the user's current research motivation.

## Forward experiment

Pressure unknown compositions that require genuinely new, semantically grounded descriptors, compare against a matched optimized typed-DAG implementation with identical caching/definition access, and then test neural ingress/egress separately. Preserve failed interpretations, unsigned key limitations, and staged evidence. Do not silently promote the behavior of this bounded calculus into a general reasoning system.

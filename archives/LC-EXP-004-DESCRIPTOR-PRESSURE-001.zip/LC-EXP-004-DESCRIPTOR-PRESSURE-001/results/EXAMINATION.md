# LC-EXP-004 — Independent experimental pressure findings

## Bound subject

LC-EXP-003 preserved archive SHA-256: `fa5a75c8cb9e61e508b86ed9871b778aa9625528e853b7bb3cc0807b206b947d`. This experimental branch **does not modify** that archive. The LC-EXP-002 archive embedded in it has SHA-256 `309a07507490ef00a9e56e329a11ce8743b866daa486f544a3c2ecebe5cb6f20`.

## Main findings

**F1 — The existing grammar cannot express alternative routes.** LC-EXP-003 accepts `C` (directed path conjunction) but rejects `CHOICE`. In a two-independent-proposition abstraction, existing conjunction-only expressions can select the left proposition, the right proposition, or the meet of both. Exhaustive 3-valued truth tables show none equals join on all assignments. This is a **bounded mathematical expressivity observation**. It does not prove the non-expressibility of alternatives in every possible external representation or natural-language intervention.

**F2 — A pressure-motivated descriptor extension is executable.** Candidate `CHOICE(path1,path2)` selects `max(F,U,T)` of two same-start, same-end, same-query-stage paths, and nested CHOICE expressions can express more options. It refuses to fabricate a single path by concatenating routes. All path witnesses, their evidence claims, source macro invocation lineage and distinct branch decisions survive. Successful agreement with a conventional typed-AST evaluator establishes implementation interoperability, **not novel AI reasoning**.

**F3 — Temporal standing remains bound.** At query stage 2, an expired route and a separately FALSE route produce `U`, not a presumed `T`. This inherits the original declared stage semantics; observational authenticity and actual real-world validity are not guaranteed.

**F4 — REASSESS's append-only condition has an order hole.** The current LC-EXP-003 implementation checks that all earlier IDs still exist with identical records but does not require earlier records to retain their *ledger positions*. The original `reassess_receipt` accepts a reordered ledger with no added IDs and a changed ledger digest. `strict_reassess` rejects this with an exact record-prefix check, without altering the original code. This is significant to historical identity / audit chronology. It does not imply a false numerical conclusion in the demonstrated equal-stage evidence fixture.

**F5 — Semantics do not emerge merely from syntax.** The candidate operator's meaning is stipulated by a formal rule selected after identifying an unmet task. The 128 generated cases (113 distinct expression strings) test unfamiliar compositions of defined rules. They do **not** test a system that creates, grounds or validates previously undefined relations on its own.

## Executions

- Predecessor frozen zip identity: hash checked by runner.
- Candidate test groups: 9 passed, 0 failures, 0 errors (final run).
- Unfamiliar compositions: 128 seeded cases; 113 unique strings; 2–6 branches; all expected values computed independently from generated truth values.
- Two-route truth table: 9/9 combinations, three engines.
- Negative fixtures: incompatible endpoints, incompatible temporal stage, malformed arity, incomplete nested choices.
- Reassessment fixture: historical F -> new T from later knowledge of earlier time, ledger and original expression retained.
- Comparator: typed AST control reproduces values and provenance projections; candidate is not uniquely advantageous.
- Exploratory timing: `exploratory_benchmark.json` includes cold and warm Python timings by 2,8,16,64 alternative branches; unequal cache/compiler settings prevent claims of speed or memory superiority. Never compare this directly to prior LC-EXP-003 performance figures.

## Proposed next discriminating experiment

1. Specify the **semantics** of combining CHOICE *inside* serial composition, including how witnesses distribute, how per-branch temporal validity binds, and how exponential witness expansion is avoided.
2. Compare lazy witness DAG and expanded enumeration using structurally independent test generation and a matched conventional algebraic baseline.
3. Require an explicit primitive-admission record: motivating expressivity gap, novel irreducible distinction, alternate encodings, negative tests, and measurable net benefit. Preserve rejected candidate primitives as negative evidence.
4. Only then add neural interpretation and test whether unfamiliar linguistic inputs are reliably translated into novel compositions. Preserve time-anchor self-grounding as a separate research objective.

## Claim ceiling

`BOUNDED_SYMBOLIC_COMPOSITION_DEMONSTRATED` for candidate semantics. `HISTORICAL_LEDGER_PREFIX_DEFECT_REPRODUCED`. No independently **discovered** semantic meanings, no model-weight learning, no universal decipherability, and no demonstrated efficiency superiority.

# LC-EXP-001 — Executed Findings

**Run:** 2026-10-17  
**Grammar:** `LC-EXP-001-GRAMMAR-1.0.0`  
**Registry SHA-256:** `c4a8244df7029e4e9af566a78cbe1e0013847fa9624631e6ca587005f9582400`  
**Status:** CPU-based experimental vertical slice; not a general semantic intelligence system.

## Conformance and fidelity

- **7 / 7 test groups passed:** `True`; failures `0`, errors `0`.
- **220** procedurally generated compositions and **17,820** reference-valued full-valuation cases checked independently by two interpreters against a third explicit oracle. The generation seed and suite are public, not an independent holdout.
- Stages `0,1,2` of the same `G1(A)` policy evaluate to `U,T,F` with the expected missing/observed evidence distinctions.
- An exhaustive 9-valuation De Morgan rewrite passed. A negation-scope mutation was rejected with a counterexample.
- `REASSESS` records preserved the earlier conclusion rather than rewriting it after later observations.
- Two separate parsers (recursive descent and iterative frame stack), AST versus postfix VM, and separately written reconstruction routines agreed on the semantic support for the episode.
- Audit trace chain validation: **True**. The chain is untrusted unless the root or digest is externally preserved; it contains no signature, and there is no external evidence authentication.

## CPU repeated-query microbenchmark

**6,000 equivalent toy queries, 5 trials per arm, median time.** Measurements vary by execution conditions and do not include neural ingestion, speech/image perception, generation, or training. `tracemalloc` is not process RSS.

| Experimental arm | Median µs/query | Python traced peak bytes, 300 queries |
|---|---:|---:|
| `typed_uncached` | 3.439 | 66,469 |
| `typed_cached` | 5.522 | 6,345 |
| `lc_reuse_cached` | 10.450 | 9,644 |
| `lc_reuse_no_result_cache` | 9.503 | 85,016 |
| `lc_no_reuse_no_result_cache` | 28.627 | 172,220 |

**Finding:** This implementation's conventional typed evaluator is faster than its lexiconic counterpart. Definition reuse improves lexicon timing relative to turning reuse off; result caching is not worthwhile for this tiny expression. There is no evidence here that this lexicon surpasses a conventional symbolic system, much less modern LLM inference.

**Encoding-size illustration:** single lexicon expression `5` bytes; repeated conventional JSON tree `107` bytes; full lexicon registry `474` bytes. This compares serialized examples, not equally optimized shared-reference encodings; an ordinary typed system can store its rule once too.

## Delimited achievements

1. **Established:** bounded representation, compositional operations, direct structure evaluation, two-implementation agreement, explicit uncertainty, versioned definitions, auditable (not authenticated) history, and an example of reconstructive faithfulness.
2. **Not established:** emergent grammar discovery, formal proof of general semantic preservation, interpretability without a provided specification, neural-model superiority, token efficiency, scaling advantage, unknown-future decipherability, provenance authenticity or historical Codex implementation.
3. **Recommended next pressure point:** introduce explicit time/event relationships *inside* the expression system rather than relying on staged evidence externally. Predeclare a grammar discovery experiment and a truly independent held-out suite; compare against an optimized conventional typed DAG with the same reuse and caching facilities.

## Reproduce

```bash
python run_all.py
```

The package includes the complete source, grammar, immutable-version registry, tests, audit trace, raw benchmark JSON, and this findings report. Running `run_all.py` regenerates the results and overwrites measured reports with measurements from that machine.

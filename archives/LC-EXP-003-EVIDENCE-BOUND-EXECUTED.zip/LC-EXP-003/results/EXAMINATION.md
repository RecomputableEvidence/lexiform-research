# LC-EXP-003 / Executed examination

**Admission:** BOUNDED EXECUTABLE BEHAVIOR OBSERVED; broader semantic and efficiency claims WITHHELD.

## Predecessor, historical object

- `LC-EXP-002-EXECUTED-SUCCESSOR.zip` SHA-256: `309a07507490ef00a9e56e329a11ce8743b866daa486f544a3c2ecebe5cb6f20`.
- Read-only sequential examination SHA-256: `336e1711312651737cab9cfa2787704f80729950b6049f5b0506ddbf480ddb71`.
- Clean extraction: 28/28 manifest entries agreed; predecessor 16/16 unittest groups passed. Re-executed external probes and preserved new output.

## New demonstrations

- The stage-0 observation of `R(A,B)` with claimed validity `[0,1)` is **not** treated as current at query stage 2 even when `R(B,C)` has new stage-2 evidence. The conjunction returns `U`, preserving the excluded historical ID and the eligible recent ID. Extending the older observation's *declared* interval changes that outcome, but does not authenticate the extension.
- A retrospective assertion observed at stage 2 about stage 0 remains invisible at knowledge cutoff 0 and becomes visible at cutoff 2. That is a change in **available evidence**, not retroactive rewriting of earlier knowledge.
- An invariant expression can shift `T → F` under an append-only successor ledger; previous and next projections, original expression, observation IDs, and independent receipts are preserved.
- A restricted associativity rewrite `C(C(x,y),z) → C(x,C(y,z))` preserved projection under tested evidence in both independently implemented execution mechanisms. It is one declared rule, not a general semantic equivalence engine.
- Versioned `H1` and expanded form yield equal semantic projections yet different recorded source expressions and definition lineage.
- Cache keys bind a DAG node to evidence digest, query stage, knowledge cutoff, registry digest, and semantic-contract ID. Changing any tested context did not reuse a stale result. Returned value mutation cannot corrupt cached state.
- Negative boundary fixtures rejected malformed stage types, negative stages, duplicate observation IDs, invalid intervals, undeclared open persistence, unknown macro version/content bindings, noncontiguous paths, and mismatched query scopes.
- Seeded generative suite tested 128 independent cases, with 65 distinct expression strings observed and a separately coded direct truth-table oracle. This is not 128 independent semantic forms.

## Evidence-index and computational ablation

Compared with the predecessor's 4,096 row inspections for a 64-link/64-record path, the successor performs **64 candidate-row inspections per fully evaluated path**, plus a **64-record index build**. This improvement comes from indexing; it is available to the matched conventional comparator as well.

The `results/benchmark.json` records the four arms, at lengths 8,16,32,64, using 7 cold evaluations, 40 warmed evaluations, a separate index-build timer, and Python `tracemalloc` peak allocations. All arms use the **same indexed evidence** and now produce the **same full provenance envelope**. The graph variant does not show a consistent end-to-end runtime advantage; its cold cache initialization is relatively expensive. Warm memoization avoids repeated lookups for both typed and lexicon implementations, and has similar costs under these bounded tests. These timings are Python microbenchmarks, not full LLM cost estimates. Build and memory costs must not be omitted when calculating net efficiency.

## Retained uncertainties / limits

- Evidence validity is a source's **declared interval**, not attested fact, legality, authority or physical persistence. An `open_asserted` entry remains an assertion, not an independent continuity proof.
- The last-observed-eligible convention can discard earlier relevant disagreement at different observed stages; that is a semantics choice requiring domain-specific scrutiny before applied use.
- Both new interpreters share a common indexed evidence store/selector and input specification, so an indexing or selection mistake could be common-mode. The conventional comparator also shares its parser grammar.
- Reassessment appends asserted facts but does not adjudicate their truth, source reliability, or legal standing.
- The cache is in-process. It uses Python objects and full copied result envelopes; memory and serialization benefits are unproven. A short symbol and expanded expression can have the same computational evaluation cost.
- All tests were constructed locally; no blind external adjudication or real-world data applied. Exact expressions and evidence fixtures are inspectable.
- Generalization to independently discovered descriptors, unbounded nesting, neural interpretation, full natural-language semantics or very large datasets remains untested.

**Disposition:** preserve as a newly tested, bounded successor; efficiency superiority and general meaning-preserving computation remain WITHHELD.

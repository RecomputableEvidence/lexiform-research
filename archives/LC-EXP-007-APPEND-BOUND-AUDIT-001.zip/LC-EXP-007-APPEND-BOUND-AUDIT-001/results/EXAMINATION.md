# LC-EXP-007 — Independent pressure and development examination

## Scope and identity

Candidate predecessor LC-EXP-006 frozen SHA-256: `00c801c2a1068c20a370ee3de539abd064b9254ec726f69b627f3b0be454ffec`. All 16 predecessor manifest entries independently recalculated; 25/25 inherited test groups reproduced (LC-005: 13; LC-006: 12). The predecessor is embedded unmodified.

This LC-EXP-007 package is a separate experimental successor. It is **not** a restoration of the historical 2025 Codex and is not a neural model training experiment.

## New passing tests

10/10 successor test groups PASS, 0 failures, 0 errors. They include: independently recomputed chained tip over 160 appends; forged/tampered proof rejection; historical identifier reuse check; snapshot immutability through public API; temporal lookup parity with original ledger across 128 generated rows and randomized query conditions; 64-segment witness-DAG full-graph and indexed witness parity with separately coded `TypedAudit`; corroboration retaining truth while changing evidence identity; future-observation limits; forged cross-store reuse; and 128 independent oracle comparisons during incremental updates.

During development, the initial provisional successor did not construct `FrozenDefinitions` with the predecessor's required H1/H2 entries, causing test import failure. The fixture was corrected before acceptance. A later integrity examination identified the need for a prior-ID set in append verification; the verification contract was strengthened and its negative test added before freeze. These changes do not retroactively rewrite predecessor records.

## Observed effects

- Trusted in-process append-chain construction updates only the new row commitment. Its incremental tip differs from predecessor whole-ledger SHA-256 by design; it is not asserted to be the same digest convention.
- Old ledger snapshots continue to exclude later rows. Invalid or duplicated new evidence is rejected without committing.
- An unrelated append changes the ledger commitment but does not require relevant evidence reselection or graph recomputation.
- Additional corroborating evidence retains the truth value but changes the node/root content digest and witness evidence IDs.
- Adding contradictory evidence changes `T` to `U` in a single-link demonstration. The original `T` and first evidence ID remain available by the earlier audit handle.
- For the 64-segment path, roots and complete node sets match full re-evaluation, and path witnesses for indices 0, 1, 2^32 and 2^64−1 agree with an independently implemented full-graph witness selector. Syntactic derivations do not imply independent physical observations.
- The new `witness(handle,index)` avoids exporting every DAG node. `full_graph(handle)` remains available for audit parity but is explicitly requested.

## Performance pressure (Python CPU, measured within this execution)

| Segments | Append-chain median (ms) | Full ledger rebuild median (ms) | Root-only A (ms) | Root-only B (ms) | Full graph requested (ms) | One witness (ms) |
|---|---:|---:|---:|---:|---:|---:|
| 8 | 0.01682 | 0.20670 | 0.02792 | 0.02468 | 0.80839 | 0.16656 |
| 32 | 0.02042 | 0.71517 | 0.04040 | 0.03304 | 3.60021 | 0.73437 |
| 64 | 0.02072 | 1.35863 | 0.05025 | 0.04262 | 7.02409 | 1.77436 |

Four repetitions, eight unrelated append events per repetition, on CPU using `perf_counter_ns`; refer to `benchmark_007.json` for platform, implementation distinctions and detailed measurements. These are different **operations**; row-to-row ratios cannot be interpreted as matched system performance comparisons. Both root-only arms employ the same LC-007 algorithm, with different parsers. No inference should be made about GPU, full LLM inference, authenticated storage, or general workloads.

## Adversarial findings and limits

**F007-01 — TRUSTED_MEMORY_ONLY (OPEN):** Python store internals can be intentionally mutated by code with raw object access. Public API checks and hash-linked receipts do not establish adversarial memory integrity. Production persistent append would require separate audited storage and authentication controls.

**F007-02 — ANCHOR_AND_ID_STATE_REQUIRED (CONSTRAINED):** Hash linking proves declared ordering relative to a trusted previous digest, but historical identifier uniqueness is not provable from the digest alone. Receipt verification now requires trusted prior-ID state and rejects forged same-ID appends. A complete replay from records remains a valid independent check.

**F007-03 — PROCESS_LOCAL_HISTORY (OPEN):** Revision-bound audit handles and cached nodes are only valid in a live engine instance. Cross-process reconstitution and third-party-independent portable proof packets are not demonstrated.

**F007-04 — CROSS_CONTEXT_REUSE (OPEN):** Source, registry, stage, or knowledge-cutoff changes remain a refusal boundary. Different-context dependency reuse was not investigated.

**F007-05 — NO INDEPENDENT PERFORMANCE EDGE (OPEN):** Both optimized A/B variants use a shared algorithm; improvements represent avoidance of prior full-record and full-graph materialization in comparable operations, not lexicon-specific efficiency. Equal-optimization comparison to a separately engineered typed incremental evaluator remains required.

**F007-06 — NO SEMANTIC_DISCOVERY (OPEN):** The grammar is fixed, symbol interpretations externally supplied, and all observed paths are synthetic combinations. No emergence of independently grounded new meanings or alien decipherability has been demonstrated.

## Disposition

**Bounded LC-EXP-007 experiment PASSED declared in-process semantic and audit-preservation tests. Wider integrity, portable independent audit, and lexicon-specific performance admission WITHHELD.**

Recommended next pressure: durable append-only storage with externally checkable cryptographic checkpoints and restart recovery, or cross-context dependency-preserving reuse under formally constrained time transitions. Preserve this experiment as an independently dated successor without rewriting predecessor findings.

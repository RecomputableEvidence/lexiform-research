# LC-EXP-006 — Executed Examination

## Identity and predecessor

Preserved subject: LC-EXP-005-LAZY-COMPOSITION-001.zip, SHA-256 `c51ee49b709fe4bca705a058b37eac7ac155a6e322d8d78e3a5e0c24d4124791` (matches user supplied frozen receipt). All 19 predecessor manifest entries verified, 13/13 predecessor tests reproduced in temporary extraction.

New subject: LC-EXP-006-DEPENDENCY-BOUND-REUSE-001; source tree added independently. Predecessor and its recorded negative comparison remain unchanged.

## Verification

12/12 successor test groups pass, 0 failures, 0 errors. Cold/full graph identity comparison, both A/B parsers, audit-equivalent typed re-evaluation, 128 deterministic appended-evidence updates, invalid metadata, rejected reordered or altered ledger prefix, guarded macros, temporal validity, expired evidence, evidence IDs, witness selection, 64-segment `2^64` witness representation, defensive output copies and unchanged historical receipts.

One early internal candidate implementation failed graph identity checks because leaf/guard atom metadata was missing. It was repaired before the final passing test run. The earlier failure is not counted as a success.

## Confirmed structural effects

**Unrelated append:** no matching dependency leaves, 0 lookups and 0 recomputed nodes, new ledger digest still bound to returned result.

**Affected append:** matched atom is freshly selected. If its structured evidence selection differs, the affected leaf and its ancestor closure are recomputed. Historical graphs remain intact.

**Unchanged truth, changed evidence IDs:** reuses are appropriately invalidated even when the conclusion remains `T`. Audit provenance does not silently inherit stale evidence.

**Future evidence beyond knowledge cutoff:** an appended observation can change the ledger digest while the selected evidence and result root remain unchanged under the fixed knowledge cutoff. Reusing across a changed cutoff is rejected.

**Non-append mutation or reordering:** rejected rather than treated as evidence enrichment.

**Current physical standing:** the system does not authenticate observations or infer persistence beyond their declared validity windows. An evidence selection is not independent attestation of a physical state.

## Scaling experiment

Benchmark parameters: Python standard library on CPU, 8 appended records per run, 3 measurement repetitions, graph sizes for 8, 32, 64 binary-choice segments, full result/evidence DAG returned by every arm, ledger rebuilding timed separately. Each test case passes root digest parity across all arms. Microbenchmarks are illustrative and sensitive to runtime.

For 64 segments (lower is faster):

| Append scenario | Lexicon incremental A (ms) | Typed incremental B (ms) | Typed full rebuild (ms) | Mean recomputed nodes | Mean evidence lookups |
|---|---:|---:|---:|---:|---:|
| Unrelated | 7.990 | 7.271 | 28.459 | 0 | 0 |
| Last segment affected | 7.626 | 7.423 | 25.666 | 4 | 1 |
| First segment affected | 8.297 | 8.410 | 28.539 | 66 | 1 |

Immutable evidence ledger reconstruction/index preparation has a median ~1.4 ms per append in the 64-segment fixtures; it is not included in evaluation times. Complete result serialization and copying are approximately proportional to the graph's size even on unrelated evidence.

An incremental approach is faster than deliberate full rebuild on these repeated queries. **The two incremental variants use the same algorithm. Therefore this experiment does not establish a lexiconic advantage versus an equivalently optimized, independently implemented conventional incremental system.**

## Claim ceiling

- Bounded append-only selective invalidation: observed and matched against separate full re-evaluation.
- Full audit graph and witness parity: observed in declared fixtures.
- Historical ledger identity continuity: verified by prefix check within the supplied immutable ledger objects.
- Cross-context reuse, efficient persistent ledger append, real-world evidence authentication, general meaning comprehension, semantic discovery, universal decipherability, LLM inference or training, and superior efficiency over a matched incremental typed competitor: **not established**.

## Recommended next pressure

The main remaining bottleneck is *not* evidence relookup; it is rebuilding/hash-verifying the ledger and copying complete audit graphs. A next experiment should implement append proofs or a persistent immutable ledger with clearly declared trust boundaries, plus selective witness materialization, and compare it against a fully optimized conventional counterpart. Preserve the current frozen results and do not promote locally optimized reuse into a claimed lexiconic invention.

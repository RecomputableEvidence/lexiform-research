# LC-EXP-005 — Execution and Pressure Findings

## Subject

Executable branch derived from LC-EXP-004, not the historical 2025 Lexicon Codex. The original LC-004 ZIP and nested LC-003 ZIP are included unmodified, with separately checked SHA-256 identities.

## Test disposition

- Initial checks of supplied predecessor: 15/15 manifest entries matched; 9/9 candidate tests passed.
- Candidate v0.1 final: 13/13 test groups passed on first completed suite after correcting the initial independent-token-parser ambiguity (endpoint token `C` incorrectly classified as a descriptor name). Earlier incomplete and failing development runs are not reclassified as passes.
- 128 seeded tests of unfamiliar fixed-grammar compositions passed against both conventional DP and capped brute-force path enumeration. Exhaustive 3×3 truth table tests passed. All four engines use the same declared evidence semantics, which limits epistemic independence.
- Distinct-path stress: 64 binary choice segments, 256 edge evidence records, `2^64` distinct syntactic derivations, 511 stored result nodes. Random-access first/last witnesses have different node lists and different recorded evidence IDs. Full expansion was not attempted.
- Strict guard scope: guard over alternatives rejected if its entity does not occur in every possible witness; valid common-entity guards accepted. Explicit mixed-stage and endpoint inconsistencies rejected. Expired evidence remains `U`; later available evidence may change a re-evaluated claim without rewriting prior evidence.
- `REWRITE`: declared `CHAIN_CHOICE_LEFT`, `CHAIN_CHOICE_RIGHT`, `GUARD_CHOICE`, `TIME_CHOICE` distributive transformation schemas, context checks via separate typed implementation, source/target graph identities separately bound. Structural equivalence is confined to the specified grammar and its proven 3-valued algebra.
- `REASSESS`: exact ordered ledger-prefix requirement, preserved expression, prior and next query-context hashes, full evidence input records, independent typed control checks. A reordering adversary rejected.
- Receipts re-computed from archived `results/example_receipts.json` under pinned code and ledger schema: REWRITE PASS, REASSESS PASS.

## Microbenchmark observations

In this run (Python CPU, 9 cold repetitions and 40 warm queries per repetition), end-to-end benchmark at 64 distinct binary route segments:

| Evaluator | Cold median | Warm median | Output |
|:--|--:|--:|:--|
| LC-005 LazyGraph | 27.033 ms | 6.720 ms | full witness/evidence DAG |
| Conventional TypedAudit | 27.873 ms | 7.380 ms | identical full witness/evidence DAG |
| Conventional TypedDP | 3.692 ms | 0.013 ms | aggregate only; not audit-equivalent |

Both graph arms preserve the same node graph and possible witness identity, and both avoid enumerating `2^64` results. This establishes **a useful graph-algebra technique**, not lexicon-specific computational superiority. Full provenance output and deep copying are nontrivial costs. The eager comparator is deliberately unoptimized and capped, so its disadvantage is not a fair optimized-baseline comparison. Ledger index-construction costs are separately recorded.

## Open technical questions

1. Can a representation compress semantic *description size* end-to-end versus equally structured typed graphs, not merely exponential path enumeration?
2. Can learned neural receptors propose candidate compositions while preserving uncertainty and independently testable fidelity?
3. How should shared evidence dependencies, confidence calibration, and contradictory physical observations be represented beyond F/U/T summaries?
4. How are external groundings and independently authored decoding keys evaluated without relying upon shared tool assumptions?
5. Can result-bearing DAG values be reused across partially enriched ledgers safely through dependency-sensitive invalidation rather than the present conservative complete-ledger SHA key?

**Claim ceiling:** `LAZY_FORMAL_WITNESS_COMPOSITION_OBSERVED`; `AUDIT_EQUIVALENT_CONVENTIONAL_PERFORMANCE_SIMILAR`; `REWRITE_REASSESS_BOUNDED_RECEIPTS_REPRODUCED`. No admission of emergent meaning, unique lexiconic speedup, or general reconstruction completeness.

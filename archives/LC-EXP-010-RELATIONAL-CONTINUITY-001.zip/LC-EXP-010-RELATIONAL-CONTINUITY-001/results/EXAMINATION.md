# LC-EXP-010 — Independent successor examination

**Date:** 2026-10-17  
**Subject:** independently reconstructed LC-EXP-009, followed by separately constructed LC-EXP-010 candidate.  
**Scope:** executable declared-relation semantics, not external authentication or causal qualification of Lens Removal/Lens Shift.

## Predecessor

- User-provided LC009 reading export: `LC-EXP-009-Relational Historical Audit.zip`.
- The reconstruction from its embedded source sections recovered all 38 original UTF-8 members byte-for-byte against the original package manifest; LC008 predecessor supplied from the conversation matched its declared digest, making **39/39**.
- The preserved reconstructed ZIP is `LC-EXP-009-RECONSTRUCTED-RUNNABLE.zip`, raw SHA-256 `d2068668386340be540c2b943bebef4078a124e50a54e0692e5d310970af813b`.
- The unavailable original Claude ZIP's reported SHA-256 `b5fa927aa61cc397d8e5b55d7c4c181724bcbeffda8c9f3c59588213be8615a9` is **not** claimed to match the reconstructed ZIP.
- Clean extraction: `python verify_manifest.py` = 39/39; `python run_all.py` = LC009 **19/19**, predecessor LC008 suite PASS. Also independently re-executed when enclosed in LC010 (`results/reconstructed_009_fresh_reexecution.log`).

## What motivated LC010

LC009 verifies only one declared fixed-query append reassessment at a time. Collecting valid receipts is insufficient to show they form a continuous, correctly ordered sequence: receipt 2's before packet might differ from receipt 1's after packet. Nor does `sample_selection_changed` compare selected witness contents or supporting evidence.

The successor defines a bounded **relation of verified relationships**: each immediate LC009 receipt is fully replayed, its before endpoint must exactly match the preceding after endpoint, and its ordinal/commitments are domain separated and checked. Selected witness comparisons distinguish ledger-envelope changes from changes to the selected route/content and evidence IDs.

## Tests and observed results

- **15/15 LC010 test groups PASS** on Python 3.13.5 (see `results/successor_tests.log`).
- **64 seeded three-snapshot histories** validated for stable identity and scalar outcomes.
- **6/6 distinct negative/positive pressure cases matched**, including swapped events, receipt tampering, skipped intermediate, and the fact that a shorter history can still be self-consistent (`results/negative_probes.json`).
- **3-step example:** T → T → U → U, with corroborating support, contradicting evidence, and unrelated appended evidence; both truth and sampled supporting IDs are separately reported. CLI cross-process verification reproduced three steps (`results/cross_process_verification.json`).
- **Witness nuance:** unrelated append changes the witness object's ledger commitment but does *not* change the selected semantic witness content or selected evidence IDs; this is a demonstrable distinction, not a cosmetic renaming.
- **Substitution pressure:** a shorter but otherwise independently valid sequence verifies without an external reference. When presented with a trusted tip for the longer sequence it correctly fails equality. This does NOT prove absence of omitted historical events.

## Preserved development failures

First expanded test pass: **11/13 PASS; two tests failed** (`results/development_first_pass_failure.log`). The first mistakenly interpreted a changed witness ledger commitment as changed sampled meaning. The second expected a request-order variation to survive an exporter that canonicalizes witness order. Subsequent source and tests were revised to distinguish these states. No LC009 source files were changed. The final expanded suite is 15/15 PASS.

## Research determination

**Observed:** bounded multi-step declared relation verification, packet-exact adjacency, domain-separated chain commitments, and scoped witness/evidence differentiation. Cross-process verification passes on its controlled fixtures.

**Not observed:** authenticated source reports, guaranteed external event completeness, an independently trusted hash anchor, true continuity of physical conditions, independently generated semantic meaning, general learning, computational superiority, compact proof, or causal effect of the Lens methods. Both LC009 and LC010 share the same lower-level evidence selection and replay assumptions; they do not constitute independent implementations of a semantic oracle.

**Standing:** LC009 remains unchanged; LC010 is a separately attributable executed candidate that can be re-examined without replacing LC009 or retroactively upgrading its results.

# LC009 reconstruction note

This successor embeds the newly generated LC009 reconstructed runnable archive, not the unavailable original Claude archive. The reconstruction recovered the original LC009 textual files by treating the reading copy's fenced content as untrusted candidate bytes, selecting exact line endings and terminal newline variants **only when the candidate's SHA-256 matched the original manifest**. The last missing embedded non-text archive (`history/LC-EXP-008-PORTABLE-AUDIT-001.zip`) was obtained from the separately uploaded original LC008 package; its SHA-256 matched the embedded expected digest.

The reconstructed archive uses newly generated ZIP container headers and therefore has a new raw archive hash. Its individual members and source identities remain verified against the original 39-entry manifest. The prior 009 rerun and the new 010 examination are separate attribution events.

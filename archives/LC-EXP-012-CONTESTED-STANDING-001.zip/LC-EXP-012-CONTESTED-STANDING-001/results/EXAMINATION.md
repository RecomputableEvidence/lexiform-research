# LC-EXP-012 — Executed examination (frozen observation)

**Subject:** conditional, competing and cyclic claim relationships in LexiFORM, not methodological performance.

## Integrity and provenance

Unmodified LC-EXP-011 archive SHA-256: `c318faed2651141488860df697fd13d060eae700bbfefc34b8ea1332c476be86`. The source methods are preserved unmodified in `methods/` with exact hashes in `predecessor_and_methods_receipt.json`. LC-EXP-012 is an independent experimental successor; it does not assert new behaviors existed in LC-011 or in the historical time-anchor Codex.

## Actual local execution

- Targeted and generated test groups: **26/26 PASS**; recorded runtime 0.413 seconds on the initial executor.
- Deterministic generated list-form expression structures: **512 distinct expression hashes** (512 evaluated; separately generated from a seeded grammar).
- Generated synthetic claim-graph scenarios: **128 seeded cases**, with variable links, guards and admission states.
- Reordered-input invariance: **32 shuffled fixtures**, separate from the append-only historical prefix rule.
- Three evaluated pathways: a list-form descriptor evaluator with incremental grounded labeling; an ordinary typed AST evaluator using a separate characteristic-function procedure; and an independently coded finite-set complete-extension oracle for small graphs (limit 10 claims).
- All three pathways share **synthetic policy assumptions**, and both principal evaluators share the input-schema contract. Passing does not independently establish external correctness or semantic grounding.

### Demonstrated five-state episode

| Evidence/revision phase | Value under declared semantics |
|---|---|
| Original assertion | `T` |
| New opposing assertion, no priority relation | `U` |
| Admitted correction | `F` |
| Admitted correction attacking the prior correction | `T` |
| Reciprocal attack producing an unresolved cycle | `U` |

This is a finite abstract argumentation **policy choice**; the graph records a skeptical argument status, not certified facts. Admitted review relations are typed and scoped and require declared reviewer permission. Unauthenticated reviewer names and synthetic source IDs are not proof of true authority or evidence.

### Focused pressure findings

- Without admitted correction, chronological novelty does not select a winner.
- `DISPUTES` annotates contestation but does not automatically defeat a target claim. `ADDS_CONTEXT` annotates interpretation without directly changing truth. `SUPERSEDES` applies to explicit policy scope and does not rewrite prior validity periods.
- Missing or conflicting guard evidence gives unresolved standing; an explicitly false guard deactivates a link. A known true guard permits the admitted link's stipulated consequence.
- Competing corrections can lead to an `U` conclusion without invented tie-break precedence; cyclic attacks remain undecided.
- Invalid source links, duplicate identities, forged permission in the declared schema, future-dated supporting evidence, self-reference and malformed expression grammar are rejected.
- A permitted equivalent `REWRITE` keeps its complete semantic projection. `REASSESS` preserves the historical predecessor result and commits to both snapshots; unrelated evidence can change the ledger commitment while leaving the interpretation unchanged.

## Matched-output Python performance observation

Benchmarked **24 fixed query variants**, list-form and typed AST precompiled, fresh evaluator instantiated per query, same full provenance projection, 17 sampled runs, 15 loops per sample. No answer/result cache crosses query calls. Each evaluator has its own within-query state reuse and different algorithmic overhead.

| Execution | Median elapsed per query | Median traced peak allocation per timed sample |
|---|---:|---:|
| Lexiconic list evaluator | **0.317047 ms** | 19,370 bytes |
| Conventional typed evaluator | **0.401495 ms** | 123,588 bytes |

The list-form prototype is faster in *this particular Python implementation*. **The comparison does not establish a distinctive Lexiconic Cipher scaling advantage:** it reflects two independently coded algorithms with different implementation overhead, small fixtures, sampling noise, and one environment. It also excludes end-to-end neural encoding, reconstruction and deployment/maintenance costs. A separately optimized conventional typed implementation may equal or surpass it.

## Important remaining limitations

1. The attack semantics are selected by the researchers, not learned or self-grounded; a correction source with weaker real-world evidence can win if its admitted attack is stipulated.
2. Reviewers and sources are synthetically declared; not authenticated or independently judged reliable.
3. Guards are based on separate condition observations, not general dependent claim conclusions; no unrestricted recursive proof of guarded relationship admissibility is offered.
4. Prefix preservation is category-wise, not a globally timestamped/externally committed multi-type transaction history.
5. The finite-set oracle and fixtures share the method author's normative semantics and may share policy errors; the generated tests do not make their assertions representative of open-domain linguistic meaning.
6. No new weight training, independently deciphered lexicon, autonomous concept discovery or general reasoning superiority was demonstrated.

**Disposition:** executable bounded successor whose competing and conditional claim relationships produce reproducible results under a declared finite semantics. Next pressure: independent policy evaluation, asymmetric evidentiary authority and guarded relationships that themselves depend on contested propositions. Do not broaden the alphabet merely to inflate symbol count.

# LexiFORM — full-package examination and LC-008 successor disposition

**Date:** 2026-10-17. **Analyzed input:** user-supplied `LexiFORM.zip`, raw SHA-256 `1e8a89ce567bbc0a436739389be6c2bb2c5721d1040264ea0055ee1b51ae09e5`. **Method inputs:** `lens_removal.txt` SHA-256 `f9a6c997a30148a9f84998c2817b2efca21e16445dc2db4b2dbd261d9499f184`; Lens Shift v0.1.4 SHA-256 `841a12c1351df15cbabe794bf96577fe52ceab726903cee0f4e6a32bc1898e45`.

## Subject-level reconstruction, without privileging one feature

The outer LexiFORM archive contains seven LC-EXP series ZIPs. LC-EXP-001 demonstrates a small syntactic/lexical experiment; LC-002 records adversarial semantic examinations; LC-003 separates bounded evidence validity, stage and provenance; LC-004 introduces explicit alternative paths and strict append history; LC-005 represents exponentially many syntactic derivations as compact DAGs; LC-006 selectively invalidates affected nodes when appending records; LC-007 links a trusted in-memory ledger and selectively materializes historical audits.

Across the series, the shared architecture has **five different boundaries** that must not be compressed into one claim:

1. **Syntax and stipulated semantics.** Relations, path composition, guards, stages, macros and CHOICE are explicit formal operators. Interpreter agreement means a bounded shared calculus was implemented consistently. It does not prove independently grounded meaning or unknown-language decipherability.
2. **Evidence and time.** A row asserts an atom/truth/observation stage with a declared validity interval. Selection and expiration are executable, but source identity, physical observation and continuing correctness are not independently authenticated.
3. **Computation and scale.** Indexed lookups, DAG sharing, memoized reevaluation and persistent append operations reduce specific repeated work. Full-history replay, complete graph output and verification remain larger operations. The conventional typed comparators share the relevant optimizations or rules; no uniquely lexiconic advantage is established.
4. **Lineage and recoverability.** The package preserves many predecessor ZIPs and manifests. LC-007's historical audit handles were process-local. SHA-256 links bind declarations relative to a trusted anchor, not the authenticity of the source or memory outside its stated in-process trust boundary.
5. **Research standing.** Test groups, synthetic truth tables and benchmark samples demonstrate declared fixture behavior. They do not by themselves validate real-world claims, generalization, security or model-learning effects.

This is a bounded, inspectable symbolic experimental stack, not an autonomous reasoner. Treating it only as an exotic notation misses its actual evidence-contract and audit engineering; treating its computational reuse as proof of novel semantic intelligence overstates the tests. Both readings are rejected by the supplied source record.

## Reproduced execution and package integrity

- Raw LC-007 package extracted directly from outer `LexiFORM.zip` is SHA-256 `b47645864323e90e95ce0408d1602cc36ef801dcbc78c244bfdf0d5954d4ac00`, now pinned as immutable LC-008 predecessor.
- LC-007 independently re-executed with 10/10 groups passing and reported 25 inherited group passes. The extracted predecessor archive's 13 manifest file hashes matched. The LC-008 dependency loader independently checked LC-006 (16 entries), LC-005 (19), LC-004 (15) and LC-003 (28) before importing any inherited modules.
- The separately supplied LC-EXP-001 experiment was executed independently: 7/7 test groups passed. LC-002 is a read-only examination package and was inspected, including its historical adversarial findings; it is not counted as a LC-008 code suite.
- The tests establish conformity for the declared bounded inputs, not mathematical completeness, physical evidence authentication, method-effect attribution or independent semantic validation.

## Lens Removal: representations stripped of assumed status

The review did not use efficiency, novelty, safety, graph compactness, a particular prior failure, or the label “lexiconic” as its exclusive center. Examining the *whole* reveals an interlocking representation/evidence/computation/audit system. The most actionable missing relation is not inside a truth operator: it lies between **a historical claim held by a live engine** and **the independent reproduction of that claim from exported historical evidence**. This explains the selected successor without assuming it proves the system's original broad ambitions.

## Lens Shift operational examination

Deconstructed subject components were contrasted under `DISTINCTION` (assertion vs attestation; immutable historical claim vs current claim; root content hash vs ledger commitment; syntactic derivation vs independent measurement), `RELATIONSHIP` (historical evidence → selected claim → witness, without inheriting authority), `TRANSITION` (old T state → appended contradictory F → current U, with old T retained), `CONTEXT` (query stage versus knowledge cutoff), `SEQUENCE` (export after later append, verify in a fresh process) and `RESOURCE_BUDGET` (full-replay cost as packet size grows). The response here reports the resulting *LexiFORM findings*; it does not treat an analytical method as its own experimental subject.

This is exploratory subject-first use under Lens Shift v0.1.4. There was no preregistered attention-matched control, method-blinded evaluator, independent method replication or method-level qualification experiment. No causal claim about effectiveness of Lens Removal or Lens Shift is admitted.

## Findings, typed evidence and dispositions

| ID | Source-grounded observation | Evidence / materiality | Disposition |
|---|---|---|---|
| F008-01 | LC-007 historical `AuditHandle`s are process-local; no independent portable replay packet is provided. | Direct source/code and tests; operational boundary | **MITIGATED** by the new full-history packet verifier, not a compact cache checkpoint |
| F008-02 | A chain digest alone does not prove global historical ID uniqueness; historical ID state or full replay is necessary. | Direct LC-007 code and tests; evidentiary | **RETAINED**: LC-008 recomputes full chain and uniqueness; does not rewrite LC-007 verification |
| F008-03 | A packet may be self-consistent but represent one of two conflicting declared histories. | New negative/valid-null tests; evidentiary | **OPEN** for source authentication; external hash/tip anchors require independent establishment |
| F008-04 | Fixed grammar and external assertions remain prerequisites, rather than meanings discovered from raw physical reality. | Direct specification/runtime behavior; semantic | **OPEN**: no general semantic/physical grounding claim |
| F008-05 | Storing or selecting exponentially many syntactic witness paths is not counting independent observations. | Full-graph parity at 64 segments and 256 synthetic rows; semantic | **RETAINED**: correct label and claim ceiling |
| F008-06 | Full historical records and typed audit replay incur work proportional to input and result structure. | Five-run synthetic benchmark; operational | **RETAINED**: no succinct portability or cross-process cached-state claim |
| F008-07 | A matched independent, equally optimized typed-system cost advantage has not been established. | Predecessor recorded comparison limitations; evidentiary | **WITHHELD**: no LexiFORM-specific superiority claim |
| F008-08 | A completed cross-process verification need not use, or trust, the original LC-007 in-memory cache or handle. | 15/15 new tests; observed structural effect | **BOUNDED PASS** for a separately reconstructed typed projection |

## LC-008 successor change ledger

**Preserved invariant:** Original history and reported negative findings cannot be retroactively amended. LC-007 artifact bytes are preserved; no existing grammar, evidence semantics, archive identity, engine implementation, test fixture or historical success/failure has been modified.

**Added functionality:** `portable_audit.export_packet()` captures a snapshot after a revision—even after later appends—and binds it to definitions, expression, query stage, knowledge stage, historical ledger records and chain tip, the root result, and selected witness details. `portable_audit.verify_packet()` performs fresh LC-007-compatible hash-chain replay, global ID uniqueness checking, LC-005 `TypedAudit` full reevaluation and independent indexed witness reconstruction. `verify_packet.py` runs in a new process with frozen dependencies verified before import. Explicit `UNANCHORED` versus `EXTERNALLY_ANCHORED` labels prevent a packet's self-description from silently creating trusted authority.

**Existing issue targeted:** LC-007 `F007-03 PROCESS_LOCAL_HISTORY`. **New successor identity:** `LC-EXP-008-PORTABLE-AUDIT-001`, `CANDIDATE_EXECUTED`, `NOT_FROZEN`, `NOT_EMPIRICALLY_QUALIFIED_FOR_GENERAL_USE`.

**New execution results:** LC-008 tests 15/15 passed, failures 0, errors 0, with the LC-007 predecessor tests rerun. A historical synthetic `R(A,B)` T claim can be verified after an F assertion produces a later U state; both old and new packets survive removal of the original evaluator object. Tampering with truth/witness/hash or reusing an evidence ID is rejected. A separate consistent but contradictory packet succeeds only as unanchored consistency and fails if compared with the other history's supplied anchor. Four sampled witness indices over `2^64` syntactic possibilities match a fresh typed oracle; the other possibilities were not enumerated.

**Costs observed:** With 8/32/64 synthetic two-choice segments, 32/128/256 evidence rows were serialized into 19,136/73,178/145,378 compact JSON bytes. Complete replay took medians 4.30/18.83/38.22 ms in a single CPU process (five repetitions, excluding dependency resolution and subprocess startup). This demonstrates material portability work *with measurable cost*, not improved end-to-end efficiency or a novel cryptographic primitive.

**Post-repair repressure classification:** `FINDING_MITIGATED` for process-local audit inspectability. `INSUFFICIENT_EVIDENCE` for durable restart of the incremental cache, third-party authentication, malicious source provenance, cross-context reuse, performance superiority and real-world utility. A passing test suite and content-addressed ZIP do not elevate those claims.

## Follow-on discriminating work

A useful next successor could introduce authenticated, externally anchored durable append records and genuinely independent restart recovery, with adversarial storage edits and crash interruption; alternatively it could address context changes without reusing evidence beyond its declared validity. Such a successor should compare a separately engineered conventional typed implementation, report full integrity and parsing costs, and preserve intentional failure states. A full-history self-consistency packet alone is not a certificate of objective truth.

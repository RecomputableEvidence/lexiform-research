# LexiFORM: preserving the relation, not only the result

**Examination date:** 2026-10-17 · **Requested sequence:** Lens Removal → Lens Shift

## Conclusion

LexiFORM's concrete achievement is an inspectable symbolic interpretation whose evidence, scope and earlier states can be recovered as its inputs change. It is neither merely unusual notation nor demonstrated independently grounded intelligence. The supplied lineage progressively makes the conditions of a conclusion harder to lose.

The justified next step is to make **the relation between two portable interpretations** inspectable. I created **LC-EXP-009-RELATIONAL-AUDIT-001**, a separately identified executable successor. It checks append-only reassessment across two independently replayed packets and reports precisely which object a supplied commitment matches. Its final **19/19 test groups passed**. The frozen LC008 predecessor remains embedded unchanged.[^tests][^contract]

## 1. Lens Removal — return to the whole object first

The supplied object contains eight experiment archives, including one examination-only archive. These are successive constructions, not eight independent validations. Terms, operators, evidence records, graphs, histories, tests and claim limitations form an interdependent system. Privileging novelty would miss its conventional mechanisms; privileging conventionality would miss the increasingly precise evidence and recovery contracts.[^lineage]

Read without requiring it to vindicate either position, the lineage is concerned with a durable question: **what must remain available for a changed interpretation to be intelligible without erasing the earlier one?**

- Expressions need defined meanings rather than inferred authority from their names.
- Conclusions need observation availability and applicability separated from query time.
- Alternative derivations need their own witnesses rather than invented combined paths.
- Reused computation needs a dependency basis rather than stale inherited confidence.
- Historical results need recoverable records rather than a surviving live object.
- Adjacent results need a demonstrated relation rather than assumed succession.

That last distinction motivated pressure against the current endpoint; it did not dictate a defect finding in advance. The first-pass account was saved before the targeted contracts and probes. “Lens Removal” here means suspending a privileged frame and examining the whole, not claiming literally perspective-free cognition or objective revelation.[^removal]

## 2. What the lineage actually adds

| Stage | Concrete contribution | Boundary that remains |
|---|---|---|
| LC001 | Two implementations of a small declared three-valued calculus; rewriting separated from reassessment | Shared grammar is not unknown-language decipherment |
| LC002 examination | Probes expose clock, version, evidence-ID and repeated-scanning limits in the embedded LC002 implementation | Examination is not itself a new runtime |
| LC003 | Explicit applicability/availability, pinned definitions, indexed evidence, typed audit histories | Shared evidence-selection code limits independence |
| LC004 | Candidate CHOICE over complete paths; strict ordered-prefix reassessment | New meaning is explicitly stipulated |
| LC005 | Lazy compositional witness DAGs; random access to syntactic derivations | `2^64` derivations are not independent observations |
| LC006 | Dependency-sensitive reuse after append | Fixed-context reuse is not continuing real-world validity |
| LC007 | Append-linked in-process snapshots and selective historical audit | Live handles and stores are not durable authenticated persistence |
| LC008 | Complete portable historical packets and fresh typed replay | Endpoint consistency is not append succession or source authentication |
| **LC009** | **Full-replay fixed-query append relation and scoped commitment reporting** | **No compact recovery, signatures, grounding or general security qualification** |

The earlier performance comparisons support avoidance of particular repeated work. They do not establish a uniquely lexiconic advantage against equally optimized independent conventional systems. I did not rerun benchmarks or turn stored timings into current measurements.[^lineage]

## 3. Lens Shift — discriminating subject-level findings

The second phase applied local `DISTINCTION` and `RELATIONSHIP` contracts, with context and transition variations. The exact contracts and fresh probe outputs are packaged. These are operational probes, not a controlled experiment on the methods' effectiveness.[^probes]

### F009-01 — A ledger commitment does not commit to the interpretation

**Direct observation.** I exported fresh packets over one identical ledger, first for `R(A,B)` and then for `R(Z,Q)`. Their ledger tips were identical; their declared results were `T` and `F`. LC008 accepted both against that same supplied tip and labeled them `EXTERNALLY_ANCHORED`. Changing only query stage likewise retained the ledger tip while a bounded claim changed from `T` to `U`. A supplied complete-packet hash rejected the changed packet.[^probes]

**Meaning.** This is not a false replay or broken hash. A ledger commitment properly binds the ledger. It does not bind expression, definitions, query context or chosen interpretation. LC008's documentation acknowledges trust limits, but its single label does not identify the matched boundary at the point of use.

**Disposition.** LC009 returns two explicit scope fields: ledger-record commitment match and whole-packet commitment match. It reports supplied-anchor origin as unverified and never certifies independent procurement. Source authentication remains `NOT_ESTABLISHED`.[^contract]

### F009-02 — Two valid endpoints do not establish succession

**Direct observation.** Reordering the same evidence records produced a new packet that passed standalone LC008 replay. A consistently recomputed conflicting history also passed unanchored replay. Neither acceptance establishes an append-only relationship to the original history.[^probes]

**Meaning.** LC008 verifies individual packets; it was not contracted to verify a pair's reassessment relation. This is a missing operation, not evidence that the documented single-packet contract failed. Prior in-process append checks cannot automatically be inherited by an arbitrary pair of portable packets.

**Disposition.** LC009 replays both endpoints, requires the complete old record sequence as an exact ordered prefix, freezes expression/query/definitions, and permits only a nondecreasing knowledge cutoff. Reordered histories, truncation, forks and changed-context pairs fail this operation even if each endpoint is individually valid.[^tests][^contract]

### F009-03 — Change must remain typed; null is legitimate

**Direct observation.** An unrelated append changed the ledger commitment but left root content and truth unchanged. Corroborating evidence left scalar truth at `T` while changing root content. Conflicting same-stage evidence changed `T` to `U`. With a fixed ledger and query, advancing the knowledge cutoff could change `U` to `T` as previously unavailable asserted evidence became eligible.[^tests]

**Disposition.** The successor reports scalar truth, root content, histogram, ledger commitment, knowledge cutoff and selected witness-index changes separately. Empty deltas and unchanged outcomes are accepted. Selecting another valid witness sample is not counted as changed truth. These are not confidence or authenticity measures.

### F009-04 — Recoverability still has a cost and a trust boundary

**Direct source finding.** A receipt embeds both complete endpoint packets and fully replays them. It does not preserve or restart the incremental cache. The format retains source assertions rather than authenticating observations.[^contract]

**Disposition.** No compact proof, durable store, cross-context reuse, speedup or physical continuity claim. The relation proves a bounded fact about supplied records and formal interpretation, not what occurred outside the package.

## 4. Fresh verification and evidence standing

Before execution, all **seven supplied manifests matched**: LC001 16 entries, LC003 28, LC004 15, LC005 19, LC006 16, LC007 13 and LC008 21. The supplied LC002 examination archive has no manifest; its raw ZIP identity was recorded rather than inventing one. Embedded histories with supplied counterparts matched their source ZIP bytes. The embedded executable LC002 manifest matched 28 entries.[^integrity]

Execution used disposable copies, not archived predecessors:

| Execution | Fresh result | Qualification limit |
|---|---:|---|
| Supplied LC001 | 7/7 groups | Public fixtures and shared specification |
| Embedded executable LC002 | 16/16 groups | Includes inherited tests; not a second independent sample |
| LC002 examination probes | Completed; archived findings reproduced | Old defects remain historical, not asserted as unfixed in LC009 |
| Supplied LC003 | 15/15 groups | Bounded declared semantics |
| Supplied LC004 | 9/9 groups | Candidate operator with stipulated meaning |
| Frozen LC008 runner | 15/15 groups; LC007 and inherited runners succeeded | Reports LC007 10 and inherited 25; overlap is not independent replication |
| LC009 final | **19/19 groups** | Includes 128 seeded append pairs and cross-process negative/null tests |

LC009 also preserves a failed intermediate development run: the expanded suite's supposed positive guard was not universal over all branches. The inherited engine correctly rejected it. I retained that expression as a negative fixture and replaced the positive case with one whose branches both include the guarded entity. Final passing results occurred **after** that test amendment; no earlier failure was relabeled a success.[^development]

Test counts are not proof of coverage completeness, method utility, independent semantic grounding or production security. Python 3.13.5 was the verified runtime; compatibility with every older Python release was not tested.

## 5. Why share this successor

The change addresses the current artifact's own trajectory without creating another grammar feature merely because one could be added. **Recoverable endpoints become a recoverable, explicitly bounded relation.** It also prevents a single anchoring label from suggesting more commitment scope than the supplied value covers.

The predecessor archive and method documents are preserved byte-for-byte. No earlier grammar, execution, result, failure or claim is rewritten. LC009 is an executed experimental candidate, not a general validity certificate or production release.

To inspect it, extract the successor ZIP and run:

```sh
python verify_manifest.py
python run_all.py
python verify_audit.py reassessment examples/changed_truth.json
```

Check the manifest before tests: tests intentionally regenerate current result files. The README documents packet, endpoint and full-receipt commitment options; independently established commitment origin must come from outside the object being checked.

## Method and limits

Sources were the supplied archives, included specifications, source code and recorded history, plus fresh local executions. No external fact, product or current-state claim required web sources. Direct execution, source-supported fact and interpretive inference are separated above. Source labels remain assertions. The same executor selected probes, wrote the successor and adjudicated results; there was no blinded method comparison or independent method qualification. First-pass whole-object observation preceded the saved targeted contracts; continuation was disclosed adaptive operational work, not preregistered causal research. Work stopped after the bounded repair and repressure suite, not at a claimed fixed point.

## References and reproducible evidence

All paths below are relative to the supplied archives or delivered successor ZIP.

[^lineage]: Supplied LC001–LC008 `README.md`, LC001 `spec/grammar.md`, LC003 `spec/semantic_contract.md`, and each included examination. LC002's `EXAMINATION.md` distinguishes the examination archive from embedded executable LC002.
[^removal]: Supplied `lens_removal.txt`; delivered `results/lens_removal_observation.md`, saved before targeted probe execution.
[^probes]: Delivered `results/pressure_contracts.json`, `results/probe_008.py`, `results/probe_008_results.json`; predecessor `src/portable_audit.py` and `tests/test_portability.py`.
[^contract]: Delivered `spec/contract.md`, `src/relational_audit.py`, `verify_audit.py` and `README.md`.
[^tests]: Delivered `tests/test_relational.py`, `results/tests.log`, `results/execution_receipt.json`, `results/demo_verification.json`, `results/cross_process_demo.json`, `results/predecessor_fresh.log`.
[^integrity]: Delivered `SOURCE_INVENTORY.json`, `results/source_integrity.json`, `results/embedded_identity.json`, `results/lc001_fresh.log`, `results/legacy002_fresh.log`, `results/legacy002_probes_fresh.json`, `results/lc003_fresh.log`, `results/lc004_fresh.log`, `results/lc008_fresh.log`.
[^development]: Delivered `results/development_guard_fixture_failure.log` and `.json`; final test includes the former invalid positive fixture as an explicit negative case.
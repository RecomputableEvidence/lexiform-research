"""Fresh bounded probes; predecessor code is loaded only after archive/manifest checks."""
import json
from pathlib import Path
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.parent / 'src'))
from bootstrap import resolve

with tempfile.TemporaryDirectory(prefix='lexiform-probe-') as work:
    _, manifests = resolve(work)
    from portable_audit import export_packet, verify_packet
    from registry import FrozenDefinitions
    from persistent_ledger import AppendLedger
    from selective_audit import SelectiveAudit

    definitions = FrozenDefinitions({
        'H1': {'version': 1, 'parameters': ['a', 'b', 'c'],
               'expression': 'C(R({a},{b}),R({b},{c}))'},
        'H2': {'version': 2, 'parameters': ['a', 'b', 'c'],
               'expression': 'J(P({b}),C(R({a},{b}),R({b},{c})))'}})

    def row(i, atom, value='T'):
        return dict(id=i, atom=atom, value=value, observed_stage=0,
                    valid_from=0, valid_until=1, source='synthetic probe',
                    persistence_policy='bounded')

    def packet(rows, expr='R(A,B)', q=0):
        ledger = AppendLedger(rows)
        engine = SelectiveAudit(definitions)
        snap = ledger.snapshot()
        h = engine.evaluate(expr, snap, q, 0)['audit_handle']
        return export_packet(engine, h, snap, definitions, [0])

    rows = [row('a', 'R(A,B)'), row('z', 'R(Z,Q)', 'F')]
    p = packet(rows)
    different_expression = packet(rows, 'R(Z,Q)')
    different_time = packet(rows, q=1)
    reordered = packet(list(reversed(rows)))
    fork = packet([row('a', 'R(A,B)', 'F'), rows[1]])
    appended = packet(rows + [row('b', 'R(A,B)', 'F')])
    unrelated = packet(rows + [row('x', 'R(X,Y)')])
    result = {
        'dependency_manifests': manifests,
        'same_ledger_different_expression': {
            'tips_equal': p['ledger']['tip'] == different_expression['ledger']['tip'],
            'before_value': p['expected']['value'],
            'after_value': different_expression['expected']['value'],
            'verifier': verify_packet(different_expression, trusted_ledger_tip=p['ledger']['tip'])},
        'same_ledger_different_time': {
            'tips_equal': p['ledger']['tip'] == different_time['ledger']['tip'],
            'before_value': p['expected']['value'],
            'after_value': different_time['expected']['value'],
            'verifier': verify_packet(different_time, trusted_ledger_tip=p['ledger']['tip'])},
        'reordered_individually_valid': verify_packet(reordered),
        'fork_individually_valid': verify_packet(fork),
        'exact_append': {'prefix': appended['ledger']['records'][:len(rows)] == p['ledger']['records'],
                         'before_value': p['expected']['value'], 'after_value': appended['expected']['value']},
        'unrelated_append': {'prefix': unrelated['ledger']['records'][:len(rows)] == p['ledger']['records'],
                             'root_unchanged': unrelated['expected']['root_id'] == p['expected']['root_id']}}
    try:
        verify_packet(different_expression, trusted_packet_hash=p['packet_sha256'])
        result['packet_hash_changed_expression_rejected'] = False
    except ValueError as e:
        result['packet_hash_changed_expression_rejected'] = str(e)
    (ROOT / 'probe_008_results.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps(result, indent=2, sort_keys=True))
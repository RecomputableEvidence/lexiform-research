# LC-EXP-011 — Execution and examination

**Date:** 2026-10-17  
**Status:** executed bounded candidate, not empirical qualification of autonomous semantic discovery.  
**Predecessor:** verified archive LC010 (copied unmodified into `history/`).

## Research question

Can claim relationships and evidence-driven reassessment be represented without conflating an assertion, a relationship asserting precedence or challenge, a declared admissibility decision, and the currently warranted interpretation? Can unfamiliar compositions preserve this separation across three independent evaluation implementations?

## Fresh predecessor check

- LC-EXP-010 manifest: **23/23** matched in fresh extraction.
- LC-EXP-010 successor tests: **15/15 passed**.
- The LC010 historical ZIP is retained without modification and does not silently acquire LC011 standing.

## Observed successor results

- **52 targeted assertions passed** including nine strong-Kleene De Morgan truth-table valuations, negative schema and mutation tests, historical prefix tests, and directional/context-sensitive effects.
- **512 structurally distinct seeded expressions** agreed across (1) list-form recursive interpreter, (2) conventional typed AST interpreter, and (3) separately coded reference oracle; generated over 712 candidate draws with fixed seed `20261017`.
- Same synthetic proposition, successive knowledge cutoffs: `T → U → U → F` (original assertion, later contradiction, unadmitted correction proposal, then admitted correction).
- The comparison latest-stage heuristic returns `F` at the earlier conflict stage where the candidate returns `U`. This is a **design-policy difference**; neither is validated as true to external reality.
- Admitted dispute marks a claim as challenged; it does not by itself refute it. Supersession is effective only at the specified later query interval. Admitted contextual enrichment changes qualification without automatically changing truth.
- `REWRITE` uses declared De Morgan equivalence; `REASSESS` keeps the earlier interpretation and its distinct hash, not a rewritten predecessor.
- An unrelated append does not affect an existing semantic projection. Corroboration changes supporting IDs even when the scalar remains unchanged.

## Main remaining architectural pressure

The current prototype still treats a review decision as *declared*, not authenticated or independently justified. In a contested domain the meaning of `CORRECTS` remains conventional, not discovered. Novelty is in the *compositions produced under the known grammar*, not in grounded semantic primitives invented independently.

There is also no semantic competition between accepted graph-wide revisional claims across diverse propositions: v0.1 operates at a same-proposition granularity. Grouped, conditional, nonlocal, or conflicting revision authorities require a future experiment.

## Performance finding

The preliminary same-process 34-expression CPU comparison measures complete normalized scalar-and-provenance output from both candidate and conventional controls. **No efficiency advantage is established**; the conventional typed evaluator was faster in the sampled trial. `benchmark_observed.json` records medians and traced peaks. These are small Python measurements, not large-scale confidence intervals, LLM comparisons, or production-profiled costs.

## Claim ceiling

Demonstrated: reproducible, bounded, explicitly admitted claim-relationship semantics and evidence-bound historical reassessment in executable synthetic fixtures, with three-path semantic agreement and negative controls.

Not demonstrated: actual-world truth/authority verification, all possible compositions, historical completeness, universal intelligibility, independent semantic discovery, lexicon-specific computational advantage, autonomous claim adjudication, or portability to arbitrary physical interpreters.

## Next discriminating pressure

Introduce **conditional and competing relationship scopes** with separate admission authorities and purposely contradictory review decisions; hold out relational structures rather than merely varying their syntactic trees. If an independently written reference policy disagrees, preserve it as a candidate semantic defect rather than extending the grammar to make the test pass post hoc.
